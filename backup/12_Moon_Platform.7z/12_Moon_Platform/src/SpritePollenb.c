#pragma bank 1

#include "..\res\src\pollenb.h"
#include "Scroll.h"
#include "SpriteManager.h"

UINT8 bank_SPRITE_POLLENB = 1;

void Start_SPRITE_POLLENB() {
	THIS->flags = 0x06;

}

void Update_SPRITE_POLLENB() {

}

void Destroy_SPRITE_POLLENB() {
	
}