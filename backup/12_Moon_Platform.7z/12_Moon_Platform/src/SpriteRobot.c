#pragma bank 3

#include "main.h"
#include "ZGBMain.h"

#include "..\res\src\robot.h"
#include "Scroll.h"
#include "SpriteManager.h"
#include "Sound.h"

UINT8 bank_SPRITE_ROBOT = 3;

extern UINT8 Level;
extern UINT8 village_mode;
extern UINT8 Dialog_pos;

const UINT8 robot_walk[] = {6, 2, 3, 4, 5, 6, 7};
const UINT8 robot_idle[] = {2, 0, 1};
const UINT8 Map_Position[] = {
	2,2,
	4,6,
	4,9,
	4,15,
	4,26,
	14,26,
	20,26,
	28,26,
	28,21,
	24,15,
	19,14,
	17,5,
	23,5,
	29,5
};

const INT8 Scared_Jump[] = {
	 0,-4,
	-1,-3,
	-1,-2,
	-1,-1,
	-1, 0,
	-1, 0,
	-1, 0,
	-1, 1,
	-1, 2,
	-1, 3,
	-1, 4
};

struct RobotInfo { //Speeds and stuff
    UINT8 px; //speed
	UINT8 py;
	INT8 dir; //0-L 1-R
	INT8 sp; //Speed Po
	UINT8 tile; //tile ground Pos
	INT8 state; 
	INT8 fl; //float
	INT8 fr; //jump frame
};

void Start_SPRITE_ROBOT() {
	struct RobotInfo* data = (struct RobotInfo*) THIS->custom_data;
	data->fl = 0;
	data->state = 0;
	THIS->flags = 0x00;
}
//PlayFx(CHANNEL_1, 32, 0x27, 0xC5, 0xF8, 0x73, 0xC6);
void Update_SPRITE_ROBOT() {
	struct RobotInfo* data = (struct RobotInfo*) THIS->custom_data;
	UINT8 x = THIS->x;
	UINT8 y = THIS->y;
	if (current_state == STATE_MENU){
		data->px = (Map_Position[(Level<<1)]<<3)-4;
		data->py = (Map_Position[(Level<<1)+1]<<3)-8;
		SetSpriteAnim(THIS, robot_walk, 30);
		if (x < data->px) THIS->x+=2;
		if (x > data->px) THIS->x-=2;
		if (y < data->py) THIS->y+=2;
		if (y > data->py) THIS->y-=2;
	}
	if (current_state == STATE_VILLAGE){
		if (village_mode == 0){
			SetSpriteAnim(THIS, robot_walk, 15);
			if (data->fl == 3) {
				data->fl = 0;
				THIS->x++;
			}
			data->fl++;
			if (x == 70) {
				SetSpriteAnim(THIS, robot_idle, 10);
				village_mode++;
				#ifdef CGB
				delay(3000);
				#else
				delay(1500);
				#endif
				data->fl = 0;	
			}
		}
		if (village_mode == 3){// Scared sound
			if (data->fl == 0) {PlayFx(CHANNEL_4, 32, 0x3F, 0xF3, 0x34, 0x80); delay(200); PlayFx(CHANNEL_1, 32, 0x5D, 0x0D, 0xF2, 0x5C, 0xC6);}
			THIS->x+=Scared_Jump[data->fl];
			THIS->y+=Scared_Jump[data->fl+1];
			data->fl+=2;
			if(data->fl == 22) {village_mode++; data->fl = 0;}
		}
		if (village_mode == 5){//JUMP ON DOL
			if (x == 60) PlayFx(CHANNEL_1, 32, 0x27, 0xC5, 0xF8, 0x73, 0xC6);
			if (x < 84) THIS->y--;
			if (x > 84) THIS->y++;
			if (x == 112) village_mode++;
			THIS->x++;
		}
		if (village_mode == 6){ 
			if (x == 166) { village_mode++; SetState(STATE_VILLAGE);}
			THIS->x++; 
		}
		if (village_mode == 7){
			THIS->flags = 0x20;
			if (data->fl == 2) {data->fl = 0; THIS->x--;} 
			data->fl++;
			if (THIS->x == 56) {village_mode++; PlayFx(CHANNEL_1, 32, 0x27, 0xC5, 0xF8, 0x73, 0xC6);}
		}
		if (village_mode == 8){
			if (x > 46) THIS->y--;
			if (x < 46) {
				THIS->flags = 0x00;
				if(y == 103) village_mode++;
				THIS->y++;
			}
			THIS->x--;
		}
	}
}

void Destroy_SPRITE_ROBOT() {
	
}