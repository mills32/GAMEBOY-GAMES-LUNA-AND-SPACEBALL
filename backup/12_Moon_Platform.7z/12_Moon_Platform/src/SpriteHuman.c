#pragma bank 3

#include "..\res\src\human.h"
#include "Scroll.h"
#include "SpriteManager.h"

UINT8 bank_SPRITE_HUMAN = 3;

void Start_SPRITE_HUMAN() {
	THIS->flags = 0x06;

}

void Update_SPRITE_HUMAN() {

}

void Destroy_SPRITE_HUMAN() {
	
}