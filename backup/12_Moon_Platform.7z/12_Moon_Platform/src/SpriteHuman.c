#pragma bank 3

#include "main.h"
#include "ZGBMain.h"

#include "..\res\src\human.h"
#include "Scroll.h"
#include "SpriteManager.h"

UINT8 bank_SPRITE_HUMAN = 3;

const UINT8 Human_idle[] = {2, 0, 1};
const UINT8 Human_walk[] = {3, 2, 3, 4};

void Start_SPRITE_HUMAN() {
	THIS->flags = 0x23;
	SetSpriteAnim(THIS, Human_walk, 15);
}

void Update_SPRITE_HUMAN() {
	//THIS->x--;
}

void Destroy_SPRITE_HUMAN() {
	
}