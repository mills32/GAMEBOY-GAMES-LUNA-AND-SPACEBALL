﻿#pragma bank 2
#include "main.h"
#include "keys.h"

UINT8 bank_STATE_RUINS = 2;

//LATIN ¿¡áéíóúñ = {[@=|#>*

void Start_STATE_RUINS() {
	SPRITES_8x16;
	SHOW_SPRITES;
	
	//InitScrollTiles(0, 204, tiles_menu, 3);
	//InitScroll(map_menuWidth, map_menuHeight, map_menuPLN0, 0, 0, 3, map_menuPLN1);

}

void Update_STATE_RUINS() {
	
}

