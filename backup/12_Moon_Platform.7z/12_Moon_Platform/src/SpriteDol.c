#pragma bank 1

#include "..\res\src\dol.h"
#include "Scroll.h"
#include "SpriteManager.h"

UINT8 bank_SPRITE_DOL = 1;
const UINT8 dol_float[] = {2, 0, 1};

extern UINT8 village_mode;

struct DolInfo {
	INT8 mode;
    INT8 fl;
	INT8 dir;
};
void Start_SPRITE_DOL() {
	struct DolInfo* data = (struct DolInfo*) THIS->custom_data;
	THIS->flags = 0x21;
	data->fl = 0;
	SetSpriteAnim(THIS, dol_float, 15);
}

void Update_SPRITE_DOL() {
	struct DolInfo* data = (struct DolInfo*) THIS->custom_data;
	if(village_mode == 5)THIS->flags = 0x01;
	if(village_mode == 6)THIS->x++;
	if(village_mode == 7){
		if (data->fl == 2) {data->fl = 0; THIS->x--;}
		data->fl++;
	}
	if(village_mode == 8) THIS->flags = 0x21;
	if(village_mode == 9) {THIS->flags = 0x01;SetSpriteAnim(THIS, dol_float, 30);}
}


void Destroy_SPRITE_DOL() {

}