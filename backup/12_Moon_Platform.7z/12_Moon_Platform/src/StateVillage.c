#pragma bank 2
#include "main.h"
UINT8 bank_STATE_VILLAGE = 2;

#include "..\res\src\win_text.h"

#include "..\res\src\map_village0.h"
#include "..\res\src\map_village.h"
#include "..\res\src\tiles_village.h"
#include "..\res\src\player.h"
#include "..\res\src\dol.h"
#include "..\res\src\tiles_level1_w_anim.h"
#include "..\res\src\Village_Mill.h"

#include "ZGBMain.h"
#include "Scroll.h"
#include "BkgAnimation.h"
#include "SpriteManager.h"
#include "palette.h"
#include "carillon_player.h"
#include "Print.h"
#include "../res/src/font.h"
#include "keys.h"
#include "Sound.h"

extern UINT8 Language;
extern UINT8 Level;
extern UINT8 Dialog_pos;
extern UINT8 Dialog_pos1;
extern UINT8 Dialog_Map[];
extern TILE_ANIMATION Waterfall;

UINT8 village_del = 0;

const UINT16 spv_palette[] = {PALETTE_FROM_HEADER(player)};
const UINT16 bgv_palette[] = {PALETTE_FROM_HEADER(tiles_village)};

UINT16 village_x = 0;
UINT8 village_y = 0;
UINT8 village_win_y = 144;

UINT8 village_mode = 0;

extern const char Village_Dialogs0[84][10];


void Delete_Text_Village(){
	PRINT_POS(1, 1); Printf("                  ");
	PRINT_POS(1, 2); Printf("                  ");
	PRINT_POS(1, 3); Printf("                  ");
}

void Start_STATE_VILLAGE() {
	HIDE_WIN;
	SPRITES_8x16;
	SHOW_SPRITES;
	WY_REG = village_win_y;
	InitWindow(0, 0, win_textWidth, win_textHeight, win_textPLN0, 3, win_textPLN1);
	INIT_FONT(font, 1, PRINT_WIN);
	SpriteManagerLoad(1);SpriteManagerLoad(2);SpriteManagerLoad(3);
	SetPalette(bgv_palette, spv_palette, 2);
	
	if (village_mode == 0){
		clamp_enabled = 0;
		Dialog_pos = 0;
		Dialog_pos1 = 0;
		SpriteManagerAdd(SPRITE_ROBOT, 0, 13*8);
		InitScrollTiles(0, 157, tiles_village, 9);
		InitScroll(map_village0Width, map_village0Height, map_village0PLN0, 0, 0, 9, map_village0PLN1);
	}
	if (village_mode == 7){
		clamp_enabled = 1;
		scroll_target = SpriteManagerAdd(SPRITE_ROBOT, 90*8, (14*8)-2);
		SpriteManagerAdd(SPRITE_DOL, 90*8, 15*8);
		InitScrollTiles(0, 157, tiles_village, 9);
		InitScroll(map_villageWidth, map_villageHeight, map_villagePLN0, 0, 0, 9, map_villagePLN1);
		LOAD_TILE_ANIM(&Waterfall, 1, 8, tiles_level1_w_anim, 3);
		CP_LoadMusic(8,6);
	}	
}

void Update_STATE_VILLAGE() {
	switch (village_mode){
		//case 0:
		//wait for robot sprite to reach pos
		//break;
		case 1:
			SHOW_WIN;
			if (village_win_y != 104){
				WY_REG = village_win_y;
				village_y++;
				village_win_y--;
			}
			else village_mode++; 
			MoveScroll(0,village_y);
		break;
		case 2:
			PRINT_POS(Dialog_Map[Dialog_pos1], Dialog_Map[Dialog_pos1+1]);
			Printf(&Village_Dialogs0[Dialog_pos+(Language*42)][0]);
			PlayFx(CHANNEL_1, 32, 0x15, 0x83, 0xF8, 0x73, 0xC6);
			Dialog_pos1+=2;
			Dialog_pos++;
			#ifdef CGB
			delay(300);
			#else
			delay(150);
			#endif
			if (Dialog_pos == 6) {
				Dialog_pos1 = 0; 
				#ifdef CGB
				delay(10000);
				#else
				delay(5000);
				#endif 
				Delete_Text_Village();
				SpriteManagerAdd(SPRITE_DOL, 14*8, 15*8);
				village_mode++;
			}
		break;
		//case 3:
		//wait for robot sprite to jump
		//break;
		case 4:
			PRINT_POS(Dialog_Map[Dialog_pos1], Dialog_Map[Dialog_pos1+1]);
			Printf(&Village_Dialogs0[Dialog_pos+(Language*42)][0]);
			PlayFx(CHANNEL_1, 32, 0x15, 0x83, 0xF8, 0x73, 0xC6);
			Dialog_pos1+=2;
			Dialog_pos++;
			#ifdef CGB
			delay(300);
			#else
			delay(150);
			#endif
			if ((Dialog_pos % 6 == 0) && (Dialog_pos != 42)){
				Dialog_pos1 = 0; 
				#ifdef CGB
				delay(10000);
				#else
				delay(5000);
				#endif 
				Delete_Text_Village(); 
			}
			if (Dialog_pos == 42) {
				Dialog_pos1 = 0; 
				Dialog_pos = 0; 
				#ifdef CGB
				delay(3000);
				#else
				delay(1500);
				#endif 
				Delete_Text_Village();
				village_mode++;
				Dialog_pos = 0;
			}
		break;
		//case 5:
		//wait for robot to jump on dol
		//break;
		//case 6:
		//wait for dol to leave
		//break;
		case 7:
			WY_REG = village_win_y;
		break;
		case 9://start talking again
			scroll_target = NULL;
			village_mode++;
			clamp_enabled = 0;
		break;
		//clamp_enabled = 1;
		//
	}
	TILE_ANIMATE(&Waterfall, 45, 2);
}

const char Village_Dialogs0[84][10] = {
//ENG
	"ZIG: Hey!",". there's",
	"someone  ","on that  ",
	"island...","         ",
	
	"DOL: Hi! ","I'm DOL  ",
	"I Saw you","r ship   ",
	"crashing ","and I... ",
	
	"ZIG: !!! "," Er...   ",
	"Hi DOL.  ","         ",
	"I'm ZIG. ","         ",
	
	"ZIG: Coul","d you    ",
	"help me g","o to that",
	"island?. ","         ",
	
	"ZIG: This"," salty   ",
	"water cou","ld damage",
	"my body. ","         ",
	
	"DOL: Sure","! That's ",
	"GIF islan","d home to",
	"GIFS, my ","friends. ",

	"DOL: Jump"," on me!. ",
	"we'll be ","there in ",
	"no time! ","         ",
//ESP //LATIN ¿¡áéíóúñ = {[@=|#>*
	"ZIG: [Hey","!. parece",
	"que en es","a isla   ",
	"hay algui","en...    ",
	
	"DOL: [Hol","a!. Soy  ",
	"DOL. Vi t","u nave   ",
	"estrellar","se, y... ",
	
	"ZIG: !!! "," Er...   ",
	"Hola DOL.","         ",
	"Soy ZIG. ","         ",
	
	"ZIG: {Pod","r|as     ",
	"ayudarme ","a llegar ",
	"a esa isl","a?.      ",
	
	"ZIG: Este"," agua    ",
	"salada pu","ede da*ar",
	"mi cuerpo",".        ",
	
	"DOL: [cla","ro!. All|",
	"viven los"," GIF, son",
	"amigos m|","os.      ",

	"DOL: [sal","ta sobre ",
	"mi, llega","remos en ",
	"seguida! ","         "
};


const char Village_Dialogs1[42][10] = {
//ENG
	"ZIG: Hey!",". there's",
	"someone  ","on that  ",
	"island...","         ",
	
	"DOL: Hi! ","I'm DOL  ",
	"I Saw you","r ship   ",
	"crashing ","and I... ",
	
	"ZIG: !!! "," Er...   ",
	"Hi DOL.  ","         ",
	"I'm ZIG. ","         ",
	
	"ZIG: Coul","d you    ",
	"help me g","o to that",
	"island?. ","         ",
	
	"ZIG: This"," salty   ",
	"water cou","ld damage",
	"my body. ","         ",
	
	"DOL: Sure","! That's ",
	"GIF islan","d home to",
	"GIFS, my ","friends. ",

	"DOL: Jump"," on me!. ",
	"we'll be ","there in ",
	"no time! ","         ",
//ESP //LATIN ¿¡áéíóúñ = {[@=|#>*

};





