#pragma bank 2
#include "main.h"
UINT8 bank_STATE_VILLAGE = 2;

#include "..\res\src\win_text.h"

#include "..\res\src\map_village0.h"
#include "..\res\src\map_village.h"
#include "..\res\src\tiles_village.h"
#include "..\res\src\player.h"
#include "..\res\src\dol.h"
#include "..\res\src\tiles_level1_w_anim.h"
#include "..\res\src\Village_Mill.h"

#include "ZGBMain.h"
#include "Scroll.h"
#include "BkgAnimation.h"
#include "SpriteManager.h"
#include "palette.h"
#include "carillon_player.h"
#include "Print.h"
#include "../res/src/font.h"
#include "keys.h"
#include "Sound.h"

extern UINT8 Language;
extern UINT8 Level;
extern UINT8 Dialog_posx;
extern UINT8 Dialog_posy;
extern UINT8 Dialog_pos;
extern UINT8 Dialog_pos1;
extern UINT8 Dialog_timer;
extern TILE_ANIMATION Waterfall;

UINT8 village_del = 0;

const UINT16 spv_palette[] = {PALETTE_FROM_HEADER(player)};
const UINT16 bgv_palette[] = {PALETTE_FROM_HEADER(tiles_village)};

UINT16 village_x = 0;
UINT8 village_y = 0;
UINT8 village_win_y = 144;

UINT8 village_mode = 0;

extern const char Village_DialogsENG0[7][55];
extern const char Village_DialogsESP0[7][55];

void Delete_Text_Village(){
	PRINT_POS(1, 1); Printf("                  ");
	PRINT_POS(1, 2); Printf("                  ");
	PRINT_POS(1, 3); Printf("                  ");
}

void Start_STATE_VILLAGE() {
	HIDE_WIN;
	SPRITES_8x16;
	SHOW_SPRITES;
	WY_REG = village_win_y;
	InitWindow(0, 0, win_textWidth, win_textHeight, win_textPLN0, 3, win_textPLN1);
	INIT_FONT(font, 1, PRINT_WIN);
	
	SetPalette(bgv_palette, spv_palette, 2);
	
	if (village_mode == 0){
		SpriteManagerReset();
		SpriteManagerLoad(1);SpriteManagerLoad(3);
		clamp_enabled = 0;
		Dialog_pos = 0;
		Dialog_pos1 = 0;
		SpriteManagerAdd(SPRITE_ROBOT, 0, 13*8);
		InitScrollTiles(0, 158, tiles_village, 9);
		InitScroll(map_village0Width, map_village0Height, map_village0PLN0, 0, 0, 9, map_village0PLN1);
	}
	if (village_mode == 7){
		SpriteManagerReset();
		SpriteManagerLoad(1);
		SpriteManagerLoad(2);
		SpriteManagerLoad(3);
		SpriteManagerLoad(14);
		clamp_enabled = 1;
		scroll_target = SpriteManagerAdd(SPRITE_ROBOT, 90*8, (14*8)-2);
		SpriteManagerAdd(SPRITE_DOL, 90*8, 15*8);
		InitScrollTiles(0, 157, tiles_village, 9);
		InitScroll(map_villageWidth, map_villageHeight, map_villagePLN0, 0, 0, 9, map_villagePLN1);
		LOAD_TILE_ANIM(&Waterfall, 1, 8, tiles_level1_w_anim, 3);
		CP_LoadMusic(8,6);
	}	
}

void Update_STATE_VILLAGE() {
	switch (village_mode){
		//case 0:
		//wait for robot sprite to reach pos
		//break;
		case 1:
			SHOW_WIN;
			if (village_win_y != 104){
				WY_REG = village_win_y;
				village_y++;
				village_win_y--;
			}
			else village_mode++; 
			MoveScroll(0,village_y);
		break;
		case 2:
			PRINT_POS(Dialog_posx,Dialog_posy);
			Dialog_timer++;
			if (Dialog_timer == 2){
				if (Language == 0)Printf("%s",Village_DialogsENG0[Dialog_pos1][Dialog_pos]);
				if (Language == 1)Printf("%s",Village_DialogsESP0[Dialog_pos1][Dialog_pos]);
				Dialog_timer = 0;
				if (Dialog_pos & 1) PlayFx(CHANNEL_2, 32, 0xC0, 0x21, 0xD7, 0x86);
				Dialog_posx++;Dialog_pos++;
				if (Dialog_pos % 18 == 0){//next line
					Dialog_posx = 1;
					Dialog_posy++;
					if (Dialog_posy == 4){
						Dialog_posx = 1;Dialog_posy = 1;Dialog_pos = 0;Dialog_pos1++; Dialog_timer = 0;
						waitpad(J_A);
						Delete_Text_Village();
						SpriteManagerAdd(SPRITE_DOL, 14*8, 15*8);
						village_mode++;					
					}
				}
			}
		break;
		//case 3:
		//wait for robot sprite to jump
		//break;
		case 4:
			PRINT_POS(Dialog_posx,Dialog_posy);
			Dialog_timer++;
			if (Dialog_timer == 2){
				if (Language == 0)Printf("%s",Village_DialogsENG0[Dialog_pos1][Dialog_pos]);
				if (Language == 1)Printf("%s",Village_DialogsESP0[Dialog_pos1][Dialog_pos]);
				Dialog_timer = 0;
				if (Dialog_pos & 1) PlayFx(CHANNEL_2, 32, 0xC0, 0x21, 0xD7, 0x86);
				Dialog_posx++;Dialog_pos++;
				if (Dialog_pos % 18 == 0){//next line
					Dialog_posx = 1;
					Dialog_posy++;
					if (Dialog_posy == 4){
						Dialog_posx = 1;Dialog_posy = 1;Dialog_pos = 0;Dialog_pos1 ++; 
						waitpad(J_A);
						Delete_Text_Village();				
					}
				}
				if (Dialog_pos1 == 7)village_mode++;
			}
		break;
		//case 5:
		//wait for robot to jump on dol
		//break;
		//case 6:
		//wait for dol to leave
		//break;
		case 7:
			WY_REG = village_win_y;
		break;
		case 9://start talking again
			scroll_target = NULL;
			village_mode++;
			clamp_enabled = 0;
			SpriteManagerAdd(SPRITE_HUMAN, 10*8, 10*8);
		break;
		//clamp_enabled = 1;
		//SpriteManagerRemove(14);
		//SpriteManagerLoad(2); //ADD Humans
	}
	TILE_ANIMATE(&Waterfall, 45, 2);
}

const char Village_DialogsENG0[7][55] = {
//ENG
"\
ZIG: Hey!. there's\
someone on that   \
island...         ",
"\
DOL: Hi! I'm DOL  \
I Saw your ship   \
crashing and I... ",
"\
ZIG: !!!  Er...   \
Hi DOL.           \
I'm ZIG.          ",
"\
ZIG: Could you    \
help me go to that\
island?.          ",
"\
ZIG: This salty   \
water could damage\
my body.          ",
"\
DOL: Sure! That's \
GIF island home to\
GIFS, my friends. ",
"\
DOL: Jump on me!. \
we'll be there in \
no time!          "
};
const char Village_DialogsESP0[7][55] = {
//ESP //LATIN ¿¡áéíóúñ = {[@=|#>*
"\
ZIG: [Hey!. parece\
que en esa isla   \
hay alguien...    ",
"\
DOL: [Hola!. Soy  \
DOL. Vi tu nave   \
estrellarse, y... ",
"\
ZIG: !!!  Er...   \
Hola DOL.         \
Soy ZIG.          ",
"\
ZIG: {Podr|as     \
ayudarme a llegar \
a esa isla?.      ",
"\
ZIG: Este agua    \
salada puede da*ar\
mi cuerpo.        ",
"\
DOL: [claro!. All|\
viven los GIF, son\
amigos m|os.      ",
"\
DOL: [salta sobre \
mi, llegaremos en \
seguida!          "
};




