#pragma bank 2

#include "..\res\src\particle.h"
#include "Scroll.h"
#include "SpriteManager.h"

UINT8 bank_SPRITE_PARTICLE = 2;

void Start_SPRITE_PARTICLE() {
	THIS->flags = 0x06;

}

void Update_SPRITE_PARTICLE() {

}

void Destroy_SPRITE_PARTICLE() {
	
}