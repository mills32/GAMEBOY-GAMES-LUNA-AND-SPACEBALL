#pragma bank 2

#include "..\res\src\vehicle.h"
#include "Scroll.h"
#include "SpriteManager.h"

UINT8 bank_SPRITE_VEHICLE = 2;

void Start_SPRITE_VEHICLE() {
	THIS->flags = 0x06;

}

void Update_SPRITE_VEHICLE() {

}

void Destroy_SPRITE_VEHICLE() {
	
}