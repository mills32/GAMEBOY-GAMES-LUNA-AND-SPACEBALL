#pragma bank 2

#include "..\res\src\spike.h"
#include "Scroll.h"
#include "SpriteManager.h"

UINT8 bank_SPRITE_SPIKE = 2;

void Start_SPRITE_SPIKE() {
	THIS->flags = 0x06;

}

void Update_SPRITE_SPIKE() {

}

void Destroy_SPRITE_SPIKE() {
	
}