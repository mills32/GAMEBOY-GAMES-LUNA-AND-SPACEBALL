﻿#pragma bank 2
#include "main.h"

#include "..\res\src\tiles_menu.h"
#include "..\res\src\map_menu.h"
#include "..\res\src\tiles_map.h"
#include "..\res\src\tiles_map_w_anim.h"
#include "..\res\src\map_map.h"
#include "..\res\src\robot.h"
#include "..\res\src\font.h"

#include "ZGBMain.h"
#include "Scroll.h"
#include "BkgAnimation.h"
#include "SpriteManager.h"
#include "palette.h"
#include "carillon_player.h"
#include "Sound.h"
#include "print.h"
#include "keys.h"

UINT8 bank_STATE_MENU = 2;
UINT8 Menu_Mode = 0;
extern UINT8 Level;
extern UINT8 Language;
UINT8 Menu_Music = 0;
TILE_ANIMATION SeaWaves;

//LATIN ¿¡áéíóúñ = {[@=|#>*
const char Menu_Levels[28][12] = {
//ENG
	"GREEN PLACE",
	"CAVE  WORLD",
	"INTRA TERRA",//PARALLAX
	" LEVITANIA ",
	" GIF  CITY ",
	"  SWAMPS   ",//PARALLAX
	" RAINLAND  ",
	" ICE PLAIN ",
	" ICE  YORK ",//PARALLAX
	" SANDLAND  ",
	"SANDLAND  2",//PARALLAX
	"  SEQUOIA  ",
	" SEQUOIA  2",
	"   RUINS   ",//PARALLAX
//ESP	
	"LUGAR VERDE",
	"LA  CAVERNA",
	"INTRA TERRA",//PARALLAX
	" LEVITANIA ",
	"CIUDAD  GIF",
	" CI=NAGAS  ",//PARALLAX
	" PLUVIONIA ",
	"LOS  HIELOS",
	"HIELO  YORK",//PARALLAX
	" ARENALIA  ",
	"ARENALIA  2",//PARALLAX
	"  SEQUOIA  ",
	" SEQUOIA 2 ",
	"  RU|NAS   "//PARALLAX
};
  //LATIN ¿¡áéíóúñ = {[@=|#>* 
const char Menu_Musics[16][13] = {
	" MENU MUSIC ",
	"   MUSIC 1  ",
	"   MUSIC 2  ",
	"   MUSIC 3  ",
	"   MUSIC 4  ",
	" Z80  MUSIC ",
	"GIF  VILLAGE",
	"  CREDITS   ",
	
	"M>SICA  MEN>",
	"  M>SICA 1  ",
	"  M>SICA 2  ",
	"  M>SICA 3  ",
	"  M>SICA 4  ",
	" M>SICA Z80 ",
	" CIUDAD GIF ",
	"  CR=DITOS  "
};
//LATIN ¿¡áéíóúñ = {[@=|#>*
const char Menu_Language[2][13] = {
	"  ENGLISH   ",
	"  ESPA*OL   "
};

const UINT16 spm_palette[] = {PALETTE_FROM_HEADER(robot)};
const UINT16 bgm_palette[] = {PALETTE_FROM_HEADER(tiles_menu)};
const UINT16 bgm2_palette[] = {PALETTE_FROM_HEADER(tiles_map)};

/*
struct MAP_ANIMATION Asteroid;
struct MAP_ANIMATION Ball;
struct TILE_ANIMATION Star1;
struct TILE_ANIMATION Star2;
*/


void Start_STATE_MENU() {
	SPRITES_8x16;
	SHOW_SPRITES;
	ZGB_Parallax = 0;
	
	NR52_REG = 0x80; //Enables sound, you should always setup this first
	NR51_REG = 0xFF; //Enables all channels (left and right)
	NR50_REG = 0x77; //Max volume
	
	if (Menu_Mode == 0){//MENU SCREEN
		HIDE_WIN;
		SetPalette(bgm_palette,0,2);
		InitScrollTiles(0, 204, tiles_menu, 3);
		InitScroll(map_menuWidth, map_menuHeight, map_menuPLN0, 0, 0, 3, map_menuPLN1);
		CP_LoadMusic(8,0);
		SHOW_BKG;
		HIDE_WIN;
		INIT_FONT(font, 1, PRINT_BKG);
		PRINT_POS(4, 7);
		if (Language == 0)Printf("PRESS  START");
		else Printf("PULSA  START");
		PRINT_POS(4, 9);
		if (Language == 0)Printf("  ENGLISH   ");
		else Printf("  ESPA*OL  ");
		PRINT_POS(4, 8);
		Printf(&Menu_Musics[Menu_Music+(Language<<3)][0]);
		Menu_Mode = 1;
	}
	if (Menu_Mode == 2){//WORLD MAP
		CP_LoadMusic(8,0);
		InitScrollTiles(0, 56, tiles_map, 1);
		InitScroll(map_mapWidth, map_mapHeight, map_mapPLN0, 0, 0, 1, map_mapPLN1);
		SHOW_BKG;
		SHOW_WIN;
		INIT_FONT(font, 1, PRINT_WIN);
		PRINT_POS(0, 0);
		Printf("  	        ");
		WY_REG = 17*8;
		PRINT_POS(4, 0);
		Printf(&Menu_Levels[Level+(Language*14)][0]);
		SetPalette(bgm2_palette,spm_palette,2);
		SpriteManagerLoad(1);
		scroll_target = SpriteManagerAdd(SPRITE_ROBOT, 12, 12);//Player on map
		LOAD_TILE_ANIM(&SeaWaves, 1, 8, tiles_map_w_anim, 1);
		Menu_Mode = 3;
	}
}

void Update_STATE_MENU() {
	
	if (Menu_Mode == 1){//MENU
		if(KEY_RELEASED(J_UP) && (Menu_Music != 7)){
			Menu_Music++;
			PRINT_POS(4, 8);
			Printf(&Menu_Musics[Menu_Music+(Language<<3)][0]);
			CP_LoadMusic(8,Menu_Music);
		}
		if(KEY_RELEASED(J_DOWN) && (Menu_Music != 0)){
			Menu_Music--;
			PRINT_POS(4, 8);
			Printf(&Menu_Musics[Menu_Music+(Language<<3)][0]);
			CP_LoadMusic(8,Menu_Music);
		}
		if(KEY_RELEASED(J_A)){
			Language = 0;
			PRINT_POS(4, 7);
			Printf("PRESS  START");
			PRINT_POS(4, 8);
			Printf(&Menu_Musics[Menu_Music+(Language<<3)][0]);
			PRINT_POS(4, 9);
			Printf("  ENGLISH   ");
		}
		if(KEY_RELEASED(J_B)){
			Language = 1;
			PRINT_POS(4, 7);
			Printf("PULSA  START");
			PRINT_POS(4, 8);
			Printf(&Menu_Musics[Menu_Music+(Language<<3)][0]);
			PRINT_POS(4, 9);
			Printf("  ESPA*OL   ");
		}
		if(KEY_RELEASED(J_START)) {
			Menu_Mode = 2;
			SetState(STATE_MENU);
		}
	}

	if (Menu_Mode == 3){//MAP
		if(KEY_RELEASED(J_RIGHT) && (Level != 13)){
			Level++;
			PRINT_POS(4, 0);
			Printf(&Menu_Levels[Level+(Language*14)][0]);
			PlayFx(CHANNEL_2, 32, 0x80, 0xF1, 0x02, 0xC7);
		}
		if(KEY_RELEASED(J_LEFT) && (Level != 0)){
			Level--;
			PRINT_POS(4, 0);
			Printf(&Menu_Levels[Level+(Language*14)][0]);
			PlayFx(CHANNEL_2, 32, 0x80, 0xF1, 0x02, 0xC7);
		}
		if(KEY_RELEASED(J_B)) {
			Menu_Mode = 0;
			Menu_Music = 0;
			SetState(STATE_MENU);
		}
		if(KEY_PRESSED(J_START)){
			CP_StopMusic();
			Menu_Mode = 0;
			Menu_Music = 0;
			SetState(STATE_GAME);
		}
		TILE_ANIMATE(&SeaWaves, 17, 16);
	}
}

