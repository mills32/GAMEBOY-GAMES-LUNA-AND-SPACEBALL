#pragma bank 1
#include "Scroll.h"
#include "SpriteManager.h"


UINT8 bank_SPRITE_ENEMY2 = 1;

//MODE V
const INT8 e2_v[] = {
	-1,0,
	0,-1,
	1,0,
	0,1
};

struct Enemy2Info {
	INT8 mode;
	INT8 tile;
};

void Start_SPRITE_ENEMY2() {
	struct Enemy2Info* data = (struct Enemy2Info*) THIS->custom_data;
	THIS->flags = 0x05;
	data->mode = 0;
	THIS->coll_x = 0;
	THIS->coll_y = 0;
	THIS->coll_w = 15; 
	THIS->coll_h = 15; //box
}

void Update_SPRITE_ENEMY2() {
    struct Enemy2Info* data = (struct Enemy2Info*) THIS->custom_data;	
	if (TranslateSprite(THIS,e2_v[data->mode],e2_v[data->mode+1]) != 0){
		data->mode+=2;
		if (data->mode == 8) data->mode = 0;
		THIS->current_frame = data->mode>>1;
	}
}

void Destroy_SPRITE_ENEMY2() {
}