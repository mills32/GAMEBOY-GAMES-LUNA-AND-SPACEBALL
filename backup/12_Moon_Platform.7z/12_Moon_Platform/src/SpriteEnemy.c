#pragma bank 1
#include "Scroll.h"
#include "SpriteManager.h"
UINT8 bank_SPRITE_ENEMY = 1;

//Float speeds

const UINT8 enemy_walk[] = {6, 0, 1, 2, 3, 4, 5};

struct EnemyInfo {
	UINT8 tile;
	INT8 fl;
	INT8 dir;
};

void Start_SPRITE_ENEMY() {
	struct EnemyInfo* data = (struct EnemyInfo*) THIS->custom_data;
	THIS->flags = 0x01;
	data->dir = -1;
	data->fl = 0;
	SetSpriteAnim(THIS, enemy_walk, 20);
	THIS->coll_x = 2;
	THIS->coll_y = 0;
	THIS->coll_w = 14; 
	THIS->coll_h = 16; //box
}

void Update_SPRITE_ENEMY() {
	struct EnemyInfo* data = (struct EnemyInfo*) THIS->custom_data;	

	//End of Platform detector
	if (data->fl == 1){
		data->tile = GetScrollTile((THIS->x + 8), ((THIS->y + 16)));

		if (data->tile != 2){ 
			data->dir = -data->dir;
			data->fl = 0;
			//FLIP
			if (data->dir == -1)THIS->flags = 0x01;
			if (data->dir == 1)THIS->flags = 0x21;
		}
	
		if (TranslateSprite(THIS,data->dir,0) != 0){
			data->dir = -data->dir;
			if (data->dir == -1)THIS->flags = 0x01;
			if (data->dir == 1)THIS->flags = 0x21;
			data->fl = 0;
		}
	}
	data->fl++;
	if (data->fl == 2) data->fl = 0;
}

void Destroy_SPRITE_ENEMY() {
}