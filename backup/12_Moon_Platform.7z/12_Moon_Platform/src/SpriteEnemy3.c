#pragma bank 2

#include "..\res\src\enemy3.h"
#include "Scroll.h"
#include "SpriteManager.h"

UINT8 bank_SPRITE_ENEMY3 = 2;

void Start_SPRITE_ENEMY3() {
	THIS->flags = 0x06;

}

void Update_SPRITE_ENEMY3() {

}

void Destroy_SPRITE_ENEMY3() {
	
}