#pragma bank 2

#include "..\res\src\block.h"
#include "Scroll.h"
#include "SpriteManager.h"

UINT8 bank_SPRITE_BLOCK = 2;

void Start_SPRITE_BLOCK() {
	THIS->flags = 0x06;

}

void Update_SPRITE_BLOCK() {

}

void Destroy_SPRITE_BLOCK() {
	
}