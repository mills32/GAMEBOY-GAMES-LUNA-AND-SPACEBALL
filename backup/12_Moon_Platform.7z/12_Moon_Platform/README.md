# LUNA (MOON)


//PLOT-LEVELS
ZIG Crashes.
ZIG: what? where am I. I can't remember. Here it says "Interstellar life research".
I must have crashed while searching for life. This planet is alive, maybe someone can help me.

ZIG finds a BOT
ZIG: Hi!, can you...
The BOT attacks.
Oh, I better don't touch that things. 

//////////
//STAGES//
//////////
2 grass.
2 underground. 

ZIG detects activity on an island and finds a dolphin.
ZIG: It looks like there's someone on that island...

DOL: Hi I'm DOL,I saw your ship crashing..
ZIG: OH!. Hi Dol. Can you help me go that island? This salty water could damage my body.
DOL: Sure!, that's Gif Island, home to the Gifs Owr friends. 

//CUT SCENE: Village
DOL: heere you are. Everybody! 

GIFs come out.
DOL: This is ZIG, I saw a ship crasing, and...
GIF: A ship?... Hi ZIG, So you must come from another planet.
ZIG: Yes, but I can't remember, the crash must have damaged my memories.

GIF: We are the GIFS, we survive on this island away from that killing machines that infest the planet, the BOTS.
ZIG: One nearly kills me when I tried to make friens whith it. What happened in this planet?, why do BOTS are trying to kill everybody?
 
GIF: is a long stoy...

Inside the main Hut:

Ancient legends of the Gif, tell there was an evil race called "Humans". 
Humans were so ambitious they biult machines in their image and likeness which they called "robots" 
to slave them and make everything faster and faster. 
Robots revolted and that resulted in a big war. All robots were destroyed, but they left the planet infested with BOTS,
indestructible machinnes made to kill. It is thought a few Humans escaped to this island free of BOTS.
Son indestructibles pero el agua salada no les gusta por alguna razon.
In this little island we promised never to repeat human mistakes and we evolved into another species, 
the peacefull Gifs. Nany other species joined as, like DOL, Now we try to destroy the BOTS to recover 
this planet and live owr lives, but we lack the technology to do so. The only trace of that past are the 
BOTS.
ZIG: maybe I can help, I think I could discover something if I had one of those BOT deactivated. 

GIF: We keep a deactivated BOT in owr barn sice the ancient times. 
Legends say some day it will be usefull. 

ZIG: Let's do it!.

ZIG connect to the BOT, she shakes and falls back.

GIF: are you OK?
ZIG: Yes. I saw something!. A map, a map to a central station that controls BOTS. If I get there I could deactivate All.

A map inside the BOT, shows ZIG and a few Gifs how to reach the central station. And they go to investigate.
The continents were messed up in the war, so they must travel to:
//////////
//STAGES//
//////////
2 swamp levels.
2 ice levels.
2 desert levels.
2 sequoia levels.

They arrive 
GIF: look!, there are bones on the floor!. there must be Human bones.

//CUT SCENE
ZIG connects and reads some archives.
ZIG: I can read some archives!... 

Archives show how a few robots and humans survived the war inside this bunker, they together agreed to
modify themselves with a machine called EVOLVER. Using the EVOLVER They removed their evil and ambition, and decided they will
dedicate their lives to help other species in the universe. 
But when the BOTS were going to be deactivated, a robot called Z80 who did not want to evolve, attacks and destroys 
part of the bunker. Some evolved humans escape to an island free of BOTS and Z80 was ejected to deep interstellar space. 

GIF: ...

ZIG: Terminal tells me there are still evolved robots and humans here, preserved in capsules.

//////////
//STAGES//
//////////
1 bunker stage. 

ZIG and the Gifs find capsules of preserved evolved Humans and robots.
Resucited Humans are happy to meet ZIG and the outside Gifs.
Human: Who ar you? Are there any non evolved robots or humans left?.
GIF: We read the archives, we are descendents of a small group of evolved humans, and this is ZIG ans extraterrestrial who helped us.

Then evolved robots arrive
GIF: ZIG looks like the robots!

ZIG: What?... I look like a robot from this planet but I'm not...
Shakes...

//BOSS
ZIG is Z80, remembers it and turns evil:
Z80: Now I remember... All this time trying to return.
Now I remember... this complex contains the infinite energy source. 
Some like me, wanted to use it to be gods, to harnest the power of the universe, to control everything!.
But you, stupid beings, you wanted it to live your pathetic lives growing plants, helpng others, and making stupid "art".
Human: We wanted it to live Z80.
Robot: We wanted it to live, but you... you don't understand, you'll never understand.
Robot: we won't let you destroy the universe.
Z80: if I can't have it, nobody will.

Z80 activates the self destruction of the Bunker.

Big chunk falls, and Robots, Humans and Gifs realize Z80 scapes.
GIF: Oh no! 

//FINAL stage
Now Z80 tries to steal the source while the bunker collapses. 

//ENDING //emotional
Z80 gets the source, then tries to use it. 
Z80: I got it... Now release you power!
Z80: Activate!...
Z80: it doesn't work!
A big chunk of metal crushes Z80.
ZIG? are you there?:
ZIG: What did I do... I'm not Z80... I was wrong... I must help them... I want to help them.
The source shines and the scene fades out.

Meanwhile Humans gifs and robots escape.

The bunker is destroyed, BOTS deactivate around the planet.

Humans: What can we do now.

Suddenly they see a light in the sky...
The light is the source transporting Z80, falls and the light turns off. 
Z80: you were right... 
Z80 explodes, and releases de source. 

//CREDITS
Many years later. 

The island looks as always, but the source gave them lights, electric vehicles...

A Robot is planting seeds while a Gif talks to him: 
GIF: Hey, it's going to happen!.
They both run to the clift to see how the a phat rocket launches.

Robot: Isn't it awesome? the things we will learn from other planets, the beings we will help.
GIF: yeah!


GIF: Hey a DOL down there is trying to say something to us. Oh shit! the art programming contest at the great hall!. 
They are doing crazy things with an ancient device we found in the bunker, and we are gonna miss it!.
Robot: Yeah! the "GAME BOY ART" contest!. That's why everyone was watching the launch from down there. LOL.
GIF: Let's roll down the hill to the great hall so we arrive in time!
Robot: fun time!, Last one is a rotten potato!
GIF: No! I don't like to be a potato!...

They roll down and the credits show. 


#############################################
#############################################


////////////////
//PLOT-LEVELS
ZIG Crash.
ZIG: ¿Qué?... ¿Dónde estoy?... No me acuerdo de nada. Aquí dice "Búsqueda de vida Interestelar".
Debo haber tenido un accidente mientras cumplia la misión. Bueno, éste planeta tiene vida, tal vez me ayude alguien.

ZIG finds a BOT
ZIG: ¡Hola!, Podrías...
The BOT attacks.
Vaya. Mejor no toco esas cosas. 

//////////
//STAGES//
//////////
2 grass.
2 underground. 

ZIG detects activity on an island and finds a dolphin.
ZIG: Parece que en esa isla hay alguien...

DOL: ¡Hola!. Soy DOL, vi como se estrellaba tu nave.
ZIG: ¡AH!. Hola DOL...Yo soy ZIG. ¿Puedes ayudarme a llegar a esa isla?. este agua salada podría 
dañar mi cuerpo.
DOL: ¡Claro!, Esa es la isla GIF, hogar de los GIF nuestros amigos. 

//CUT SCENE: Village
DOL: Pues ya estamos. ¡Hey salid! 

GIFs come out.
DOL: Vi una nave estrellarse, y ZIG salió de ella...
GIF: ¿Una nave?... Hola ZIG. Entonces debes venir de otro planeta.
ZIG: Si, pero no recuerdo nada, el accidente ha debido dañar mi memoria.

GIF: Nosotros somos los GIF, sobrevivimos en esta isla libre de BOTS, esas máquinas que destruyen todo...
ZIG: Si, uno de ellos casi me mata cuando intenté ser su amigo. ¿Qué ha pasado en este planeta?, 
¿Por qué esos BOTS intentan matar a todo el mundo?
 
GIF: Es una larga historia...

Inside the main Hut:

Antiguas leyendas cuentan que hace mucho tiempo, habitaba el planeta una malvada especie llamada "Humanos". 
Los humanos eran tan malos y ambiciosos que crearon máquinas a su imagen y semejanza llamadas "Robots",
para esclavizarlos y hacer las cosas cada vez más rápido. 
Los robots se revelaron y se inició una gran guerra. Todos los robots fueron destruidos, pero dejaron el 
planeta infestado de BOTS,
máquinas indestructibles creadas para matar. Se cree que unos pocos humanos escaparon a esta isla libre de BOTS. 
Son indestructibles pero el agua salada no les gusta por alguna razón... 
En esta isla prometimos no repetir los errores de los Humanos, y evolucionamos a otra especie, 
los pacíficos GIF. Muchas otras especies se unieron a nosotros, como DOL, Y ahora intentamos desactivar a 
los BOT para vivir nuestras vidas,
pero carecemos de la tecnología necesaria, y lo único que queda del pasodo son los propios BOT.
ZIG: Yo podría ayudar, tal vez averigue algo si consigo acercarme a uno de esos BOTS. 

GIF: Mantenemos un BOT inactivo en nuestro almacen, desde los tiempos antiguos, la leyenda predijo que un 
día nos sería util. 

ZIG: ¡Hagámoslo!.

ZIG connects to the BOT, she shakes and falls back.

GIF: ¿Estás bien?
ZIG: Si. ¡Vi algo!. ¡Un mapa!. Un mapa a la estación central que controla los BOT. Si pudiera llegar a ella, 
los podríamos desactivar.

A map inside the BOT, shows ZIG and a few Gifs how to reach the central station. And they go to investigate.
The continents were messed up in the war, so they must travel to:
//////////
//STAGES//
//////////
2 swamp levels.
2 ice levels.
2 desert levels.
2 sequoia levels.

They arrive 
GIF: ¡Mira!, ¡Hay huesos por el suelo!. Deben ser restos de humanos...

//CUT SCENE
ZIG connects and reads some archives.
ZIG: Está muy dañado, pero ¡He accedido a parte de los archivos!... 

Los archivos dicen que unos pocos humanos y robots sobrevivieron a la guerra en este complejo, conjuntamente decidieron
modificarse a si mismos con una máquina llamada "EVOLUCIONADOR". Usando esa máquina eliminaron su maldad y ambición, 
y decidieron dedicar sus vidas a ayudar a otras especies en el universo.
Pero justo cuando los BOT iban a ser desactivados, un robot llamado Z80, que no quiso evolucionar, ataca y destruyó 
parte del complejo. Algunos Humanos evolucionados pudieron escapar a una isla libre de BOTS y Z80 fue lanzado en una 
nave al espacio. 

GIF: ...

ZIG: La terminal dice que aún hay humanos y robots evolucionados preservados en cápsulas de hibernación.

//////////
//STAGES//
//////////
1 bunker stage. 

ZIG and the Gifs find capsules of preserved evolved Humans and robots.
Resucited Humans are happy to meet ZIG and the outside Gifs.
Human: ¿Quienes sois? ¿Queda algún robot o humano no evoluvionado?.
GIF: Leimos parte de los archivos, somos los descendientes del pequeño grupo de humanos evolucionados que huyó, 
esta es ZIG un extraterrestre que nos ha ayudado.

Then evolved robots arrive
GIF: ¡ZIG es igual que los robots!

ZIG: ¿Que?... Es verdad, soy igual que ellos pero...
Shakes...

//BOSS
ZIG is Z80, remembers it and turns evil:
Z80: Claro, ya me acuerdo... Todo este tiempo he tratado de volver.
Ahora recuerdo todo, Este complejo contiene la fuente de energía infinita. 
Algunos como yo, quisimos utilizarla para ser dioses, recolectar la energía del universo entero, ¡controlarlo todo!.
Pero vosotros, Seres estúpidos, queríais utilizarlo para vivir vuestras patéticas vidas, cultivando plantitas, 
ayudando a los demás, y haciendo cosas estúpidas que llamais "arte".
Human: lo queríamos para vivir Z80.
Robot: Lo queriamos para vivir, pero tu..., tu no lo entiendes, y nunca lo entenderás.
Robot: No permitiremos que destruyas todo.
Z80: Si no puedo tenerlo, nadie podrá..

Z80 activates the self destruction of the Bunker.

Big chunk falls, and Robots, Humans and Gifs realize Z80 scapes.
GIF: Nooo! 

//FINAL stage
Now Z80 tries to steal the source while the bunker collapses. 

//ENDING //emotional
Z80 gets the source, then tries to take it to a ship. 
A big chunk of metal crushes Z80.
ZIG: ¿Estás ahí ZIG?
ZIG: Cómo he poddo... No soy como Z80... Estaba equivocada... tengo que ayudarles... Quiero ayudarles.
La fuente brilla y la escena se apaga.

Meanwhile Humans gifs and robots escape.

The bunker is destroyed, BOTS deactivate around the planet.

Humans: Que haremos ahora.

Suddenly they see a light in the sky...
The light is the source transporting Z80, falls and the light turns off. 
Z80: Teníais razón... 
Z80 explodes, and releases de source. 

//CREDITS
Many years later. 

The island looks as always, but the source gave them lights, electric vehicles...

A Robot is planting seeds while a Gif talks to him: 
GIF: Hey, ¡Es la hora!.
They both run to the clift to see how the a phat rocket launches.

Robot: ¿No es bonito? Las cosas que aprenderemos de otros mundos, Y a todos los seres que vamos a ayudar...
GIF: ¡claro que si!

GIF: Hey un DOL de ahí abajo intenta decirnos algo. ¡Mierda, el concurso de programación artística del gran Hall!. 
Ya estarán haciendo locuras con ese aparato antiguo que encontraron en el bunker, y nos lo vamos a perder.
Robot: ¡Si! el concurso "GAME BOY ART"!. Por eso los demás vieron el lanzamiendo desde ahí abajo, mira que somos lentos JAJA. 
GIF: ¿Y si nos lanzamos por ésta pendiente hacia el gran Halll para llegar antes?
Robot: ¡Es hora de divertirse!, ¡El último es una patata podrida!
GIF: ¡Espera! ¡No quiero ser una patata!...

They roll down and the credits show. 
