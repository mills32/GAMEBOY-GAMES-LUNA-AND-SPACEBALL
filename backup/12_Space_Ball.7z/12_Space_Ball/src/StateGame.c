#pragma bank 2

#include "main.h"
#include "ZGBMain.h"

UINT8 bank_STATE_GAME = 2;

#include "Scroll.h"
#include "SpriteManager.h"
#include "palette.h"
#include "Keys.h"
#include "BkgAnimation.h"
#include "carillon_player.h"

void Start_STATE_GAME() {

}

void Update_STATE_GAME() {


}
