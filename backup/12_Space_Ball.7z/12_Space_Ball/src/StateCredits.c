#pragma bank 2

#include "main.h"
#include "ZGBMain.h"

UINT8 bank_STATE_CREDITS = 2;

#include "Scroll.h"
#include "SpriteManager.h"
#include "palette.h"
#include "Keys.h"
#include "BkgAnimation.h"
#include "carillon_player.h"

void Start_STATE_CREDITS() {

}

void Update_STATE_CREDITS() {


}
