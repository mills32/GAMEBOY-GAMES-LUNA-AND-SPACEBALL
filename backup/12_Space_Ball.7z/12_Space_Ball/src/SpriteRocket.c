#pragma bank 2
#include "ZGBMain.h"

UINT8 bank_SPRITE_ROCKET = 2;

#include "SpriteManager.h"


void Start_SPRITE_ROCKET() {

}

void Update_SPRITE_ROCKET() {
	THIS->x --;
}

void Destroy_SPRITE_ROCKET() {
}