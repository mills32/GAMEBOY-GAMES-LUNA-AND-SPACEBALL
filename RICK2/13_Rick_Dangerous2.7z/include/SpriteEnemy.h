#ifndef SPRITE_ENEMY_H
#define SPRITE_ENEMY_H

#include "main.h"

DECLARE_SPRITE(SPRITE_ENEMY);

#endif