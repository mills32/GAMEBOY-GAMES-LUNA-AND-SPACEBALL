#ifndef SPRITE_BULLET_H
#define SPRITE_BULLET_H

#include "main.h"

DECLARE_SPRITE(SPRITE_BULLET);

#endif