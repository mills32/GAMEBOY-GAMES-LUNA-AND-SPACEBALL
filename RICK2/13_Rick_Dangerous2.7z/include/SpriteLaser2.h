#ifndef SPRITE_LASER2_H
#define SPRITE_LASER2_H

#include "main.h"

DECLARE_SPRITE(SPRITE_LASER2);

#endif