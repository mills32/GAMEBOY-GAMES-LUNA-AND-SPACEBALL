#ifndef STATE_LEVEL1_H
#define STATE_LEVEL1_H

#include "main.h"

DECLARE_STATE(STATE_LEVEL1);

#endif