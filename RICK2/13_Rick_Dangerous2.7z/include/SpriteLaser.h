#ifndef SPRITE_LASER_H
#define SPRITE_LASER_H

#include "main.h"

DECLARE_SPRITE(SPRITE_LASER);

#endif