#pragma bank=2
#include "SpritePlatform.h"
#include "Scroll.h"
#include "SpriteManager.h"
UINT8 bank_SPRITE_PLATFORM = 2;

UINT8 platform_y = 0;

struct PlatformInfo {
    INT8 vy;
	INT8 fl; //float
};

void Start_SPRITE_PLATFORM() {
    struct PlatformInfo* data = THIS->custom_data;
    data->vy = 1;
	data->fl = 0;
	THIS->lim_x = 30;
	THIS->lim_y = 40;
	
	THIS->coll_x = 0;
	THIS->coll_y = 0;
	THIS->coll_w = 16; 
	THIS->coll_h = 8; //box
	THIS->lim_x = 8;
	THIS->lim_y = 8;
	
	THIS->flags = 0x00; //PAL1
}

void Update_SPRITE_PLATFORM() {
    struct PlatformInfo* data = THIS->custom_data;
	
	//platform_dir = 0;
	//float
	//if (data->fl == 4){
		//data->fl = 0;
		platform_y = data->vy;
		if(GetScrollTile(THIS->x >> 3,(THIS->y-2) >> 3) != 124) data->vy = -data->vy;
		TranslateSprite(THIS,0,data->vy /*<< delta_time*/);
    //}
	
	//data->fl++;
}

void Destroy_SPRITE_PLATFORM() {
}