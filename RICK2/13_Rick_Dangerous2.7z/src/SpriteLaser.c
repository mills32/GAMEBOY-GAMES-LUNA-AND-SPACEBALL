#pragma bank=3
#include "SpriteLaser.h"
#include "Scroll.h"
#include "SpriteManager.h"
UINT8 bank_SPRITE_LASER = 3;

struct LaserInfo {
    INT8 vx;
	INT8 sx;
};

void Start_SPRITE_LASER() {
    struct LaserInfo* data = THIS->custom_data;
	THIS->flags = 0x03;
    data->vx = -1;
	data->sx = 0;
	THIS->coll_x = 0;
	THIS->coll_y = 8;
	THIS->coll_w = 8; 
	THIS->coll_h = 9; //box
	THIS->lim_x = 8;
	THIS->lim_y = 8;
}

void Update_SPRITE_LASER() {
    struct LaserInfo* data = THIS->custom_data;
	
    if (TranslateSprite(THIS,data->vx,0) > 0){
		data->vx = -data->vx;
	}
}

void Destroy_SPRITE_LASER() {
}