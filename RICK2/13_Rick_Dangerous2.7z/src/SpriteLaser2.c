#pragma bank=2
#include "SpriteLaser2.h"
#include "Scroll.h"
#include "SpriteManager.h"
UINT8 bank_SPRITE_LASER2 = 2;

const UINT8 laser2_move[] = {2,0,1};

const struct Laser2Info {
    INT8 vx;
	INT8 sx;
};

void Start_SPRITE_LASER2() {
    struct Laser2Info* data = THIS->custom_data;
	THIS->flags = 0x03;
    data->vx = -1;
	data->sx = 0;
	THIS->coll_x = 0;
	THIS->coll_y = 8;
	THIS->coll_w = 8; 
	THIS->coll_h = 9; //box
	THIS->lim_x = 8;
	THIS->lim_y = 8;
	SetSpriteAnim(THIS, laser2_move, 30);
}

void Update_SPRITE_LASER2() {
    struct Laser2Info* data = THIS->custom_data;
	
    if (TranslateSprite(THIS,data->vx,0) > 0){
		data->vx = -data->vx;
	}
}

void Destroy_SPRITE_LASER2() {
}