#pragma bank=3
#include "StateLevel1.h"
UINT8 bank_STATE_LEVEL1 = 3;

#include "..\res\src\tiles1.h"
#include "..\res\src\map1.h"
#include "..\res\src\win.h"
#include "..\res\src\pincho_anim.h"
#include "..\res\src\laser_anim.h"

#include "SpritePlatform.h"
#include "../res/src/platform.h"
#include "SpritePlayer.h"
#include "../res/src/player2.h"
#include "SpriteEnemy.h"
#include "../res/src/enemy.h"
#include "SpriteLaser.h"
#include "../res/src/laser.h"
#include "SpriteLaser2.h"
#include "../res/src/laser2.h"
#include "SpriteBullet.h"
#include "../res/src/bullet.h"

#include "ZGBMain.h"
#include "Scroll.h"
#include "SpriteManager.h"
#include "BkgAnimation.h"

extern UINT8 n_sprite_types;

struct TILE_ANIMATION pincho;
struct TILE_ANIMATION laser3;
UINT8 DIE_ANI = 0;
UINT8 DIE_ANI2 = 0;

void Start_STATE_LEVEL1() {
	UINT8 i;
	UINT8 colltiles1[] = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,186,187,0};
	UINT8 colldown1[] = {16,17,18,19,0};
	extern UWORD tiles1PAL[];
	extern UWORD player2PAL[];
	
	INIT_SPRITE(SPRITE_PLATFORM, platform, 2, FRAME_16x16, 1);
	INIT_SPRITE(SPRITE_PLAYER, player2, 3, FRAME_16x16, 8);
	INIT_SPRITE(SPRITE_ENEMY, enemy, 2, FRAME_16x16, 6);
	INIT_SPRITE(SPRITE_LASER, laser, 5, FRAME_8x16, 1);
	INIT_SPRITE(SPRITE_LASER2, laser2, 2, FRAME_8x16, 2);
	INIT_SPRITE(SPRITE_BULLET, bullet, 5, FRAME_8x16, 1);
	
	SPRITES_8x16;
	for(i = 0; i != n_sprite_types; ++ i) {
		SpriteManagerLoad(i);
	}
	SHOW_SPRITES;

	//Load palettes from their banks!
	ZGB_set_colors(tiles1PAL,2,player2PAL,3);
	
	scroll_target = SpriteManagerAdd(SPRITE_PLAYER, 5*8, 66*8);
	//scroll_target = SpriteManagerAdd(SPRITE_PLAYER, 74*8, 32*8);
	//SpriteManagerAdd(SPRITE_PLATFORM, 5*8, 12*8);

	InitScrollTiles(0, 256, tiles1, 2);
	InitScroll(map1Width, map1Height, map1PLN0, colltiles1,colldown1, 3, map1PLN1);

	//INIT WINDOW
	InitWindow(0, 0, 20, 2, mapwinPLN0, 2,mapwinPLN1);
	WY_REG = 138;
	SHOW_BKG;
	SHOW_WIN;	
	
	LOAD_TILE_ANIM(&pincho, 4, 15, pincho_anim, 2);
	LOAD_TILE_ANIM(&laser3, 2, 4, laser_anim, 2);
}

void Update_STATE_LEVEL1() {

}