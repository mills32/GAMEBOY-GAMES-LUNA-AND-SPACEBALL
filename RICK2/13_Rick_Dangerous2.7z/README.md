# GB DEMOS

Here I stored some games that are using ZGB Engine.

They are working in both DMG and GBC, But they work much better in GBC.

LUNA: a fully working platformer, just one level.

FUZZY: a de-make of fuzzy's world of miniature space golf, one level fully working, I'll add about 12 levels and I'll consider it complete.

JUKEBOX: here I'm trying to fit a lot of musics compossed in carillon editor.

RIC DANGEROUS 2: it is not really a port but a "new" version of rick 2 for gameboy with changes in gameplay and sprites. Maps are ripped from the original game and edited to look rounder and less detailed.

Thanks to ZALO for the amazing ZGB engine.