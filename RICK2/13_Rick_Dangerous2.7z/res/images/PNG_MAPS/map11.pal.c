//C:\Mis_Mega_Cosas\GB\13_Rick_Dangerous2\res\images\PNG_MAPS\map11.png
//Converti avec GBA Graphics par Br�nni
//Palette
//Taille: 5
//M�moire: 10 octets

const unsigned short map11_palette[5]=	{
0x8000, 0x7fff, 0x0000, 0x4210, 0x6318};
