/**********************************
SAMPLE PLAYER FOR GBDK
----------------------
This will play Wav files in the background 
allowing the gameboy to continue doing other things, 
even playing music. 

-Channel 3 will be used for this
*/////////////////////////////////////

#include <gb/gb.h>
#include <gb/sample.h>
#include <gb/drawing.h>

#include "samples.h" //Crash -- Scream -- Explosion -- PickUp

UWORD backcolours[] = {32733,16714,15822,19648};
extern const unsigned int Wave_BKG[360];

UINT8 play = 0;
UINT8 Set_Text = 0;
UINT8 sample = 0;
UINT16 POS = 0;
int byte = 0;

void VBL() {
	if (POS == 359) POS = 0;
	SCX_REG = Wave_BKG[POS];
	POS++;
}
void main()
{
	add_VBL(VBL);
 	if(_cpu == 0x11) set_bkg_palette(0, 2, backcolours); // if CGB
	gprint("                    ");
	gprint("4 bit PCM - 8192 Hz ");
	gprint("                    ");
	gprint("                    ");
	gprint("                    ");
	gprint(" <-SELECT  SOUND->  ");
	gprint("                    ");
	gprint("     CRASH.WAV      ");
	gprint("                    ");
	gprint("  press A to play   ");
	gprint("                    ");
	gprint("                    ");
	
	while(1){
		
		if (joypad() & J_RIGHT) {waitpadup(); sample++; Set_Text = 1; byte = 0; play = 0;}
		if (joypad() & J_LEFT) {waitpadup(); sample--; Set_Text = 1; byte = 0; play = 0;}
		if (sample < 0) sample = 0;
		if (sample > 3) sample = 3;
		
		if (joypad() & J_A) play = 1; 
		
		//////////////////////////////////////////
		switch (sample){
			case 0://CRASH
				if (Set_Text == 1){
					gotogxy(0,7);
					gprint("     CRASH.WAV      ");
					Set_Text = 0;
				}
				if (play == 1){
					
					if (byte > 4556) {byte = 0; play = 0;}
					if (STAT_REG & 2){
						play_sample((unsigned char *) &crash+(byte), 1);
						byte+=16;
					}
				}
			break;
			case 1://ROCKET
				if (Set_Text == 1){
					gotogxy(0,7);
					gprint("     ROCKET.WAV     ");
					Set_Text = 0;
				}
				if (play == 1){
					if (byte > 4340) {byte = 0; play = 0;}
					play_sample((unsigned char *) &rocket+(byte), 1);
					byte+=16;
				}
			break;
			case 2://Machine (LOOP)
				if (Set_Text == 1){
					gotogxy(0,7);
					gprint("     MACHINE.WAV    ");
					Set_Text = 0;
				}
				if (play == 1){
					if (byte > 4466) byte = 0; //LOOP
					play_sample((unsigned char *) &machine+(byte), 1);
					byte+=16;
				}
			break;
			case 3://BOING
				if (Set_Text == 1){
					gotogxy(0,7);
					gprint("     BOING.WAV      ");
					Set_Text = 0;
				}
				if (play == 1){
					if (byte > 934) {byte = 0; play = 0;}
					play_sample((unsigned char *) &boing+(byte), 1);
					byte+=16;
				}
			break;
			case 4:
			break;
		}
		if (play == 0) wait_vbl_done();
    }			
	
}

//Wave for the background
const unsigned int Wave_BKG[360] =
{
0, 0, 1, 1, 2, 2, 3, 3,
4, 4, 5, 5, 6, 6, 7, 7, 8, 8,
9, 9, 10, 10, 11, 11, 12, 12, 13, 13,
14, 14, 15, 15, 15, 16, 16, 17, 17, 18,
18, 18, 19, 19, 20, 20, 20, 21, 21, 21,
22, 22, 22, 23, 23, 23, 24, 24, 24, 25,
25, 25, 25, 26, 26, 26, 26, 27, 27, 27,
27, 28, 28, 28, 28, 28, 28, 28, 29, 29,
29, 29, 29, 29, 29, 29, 29, 29, 29, 29,
29, 29, 30, 29, 29, 29, 29, 29, 29, 29,
29, 29, 29, 29, 29, 29, 29, 28, 28, 28,
28, 28, 28, 28, 27, 27, 27, 27, 26, 26,
26, 26, 25, 25, 25, 25, 24, 24, 24, 23,
23, 23, 22, 22, 22, 21, 21, 21, 20, 20,
20, 19, 19, 18, 18, 18, 17, 17, 16, 16,
15, 15, 15, 14, 14, 13, 13, 12, 12, 11,
11, 10, 10, 9, 9, 8, 8, 7, 7, 6,
6, 5, 5, 4, 4, 3, 3, 2, 2, 1,
1, 0, 0, -1, -2, -2, -3, -3, -4, -4,
-5, -5, -6, -6, -7, -7, -8, -8, -9, -9,
-10, -10, -11, -11, -12, -12, -13, -13, -14, -14,
-15, -15, -15, -16, -16, -17, -17, -18, -18, -19,
-19, -19, -20, -20, -21, -21, -21, -22, -22, -22,
-23, -23, -23, -24, -24, -24, -25, -25, -25, -26,
-26, -26, -26, -27, -27, -27, -27, -28, -28, -28,
-28, -29, -29, -29, -29, -29, -29, -29, -30, -30,
-30, -30, -30, -30, -30, -30, -30, -30, -30, -30,
-30, -30, -30, -30, -30, -30, -30, -30, -30, -30,
-30, -30, -30, -30, -30, -30, -30, -29, -29, -29,
-29, -29, -29, -29, -28, -28, -28, -28, -27, -27,
-27, -27, -26, -26, -26, -26, -25, -25, -25, -24,
-24, -24, -23, -23, -23, -22, -22, -22, -21, -21,
-21, -20, -20, -19, -19, -19, -18, -18, -17, -17,
-16, -16, -16, -15, -15, -14, -14, -13, -13, -12,
-12, -11, -11, -10, -10, -9, -9, -8, -8, -7,
-7, -6, -6, -5, -5, -4, -4, -3, -3, -2, -1, -0,
};