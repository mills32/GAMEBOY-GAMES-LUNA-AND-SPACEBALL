#ifndef SPRITE_SHIP_H
#define SPRITE_SHIP_H

#include "main.h"

DECLARE_SPRITE(SPRITE_SHIP);

#endif