#pragma bank=2
#include "StateMenu.h"
UINT8 bank_STATE_MENU = 2;

#include "..\res\src\tiles_menu.h"
#include "..\res\src\map_plogo.h"
#include "..\res\src\map_flogo.h"
#include "..\res\src\map_menu.h"
#include "..\res\src\map_menu_anim_ball.h"
#include "..\res\src\map_menu_anim_asteroid.h"
#include "..\res\src\tile_menu_anim_star.h"
#include "..\res\src\tile_menu_anim_star2.h"
#include "..\res\src\font.h"
#include "ZGBMain.h"
#include "Scroll.h"
#include "SpriteManager.h"

#include "SpriteShip.h"
#include "../res/src/spriteship.h"
#include "SpriteUfo.h"
#include "../res/src/spriteufo.h"
#include "SpriteArrow.h"
#include "../res/src/spritearrow.h"

#include "Keys.h"

#include "BkgAnimation.h"

#include "carillon_player.h"

extern UINT8 n_sprite_types;
extern UWORD tiles_menuPAL[];
extern UWORD playerPAL[];
UINT8 Menu_Mode = 0;
//declare BKG animations
struct MAP_ANIMATION Bkg_items[2];
struct TILE_ANIMATION Tile_items[2];
UINT16 M;

void Start_STATE_MENU() {

	int i;
	HIDE_WIN;
	
	INIT_SPRITE(SPRITE_SHIP, spriteship, 3, FRAME_16x16, 4);
	INIT_SPRITE(SPRITE_UFO, spriteufo, 3, FRAME_16x16, 4);
	INIT_SPRITE(SPRITE_ARROW, spritearrow, 3, FRAME_16x16, 3);
	
	SPRITES_8x16;
	for(i = 0; i != n_sprite_types; ++ i) {
		SpriteManagerLoad(i);
	}
	SHOW_SPRITES;
	
	//Load palettes from bank 2!!!
	ZGB_set_colors(tiles_menuPAL,3,playerPAL,3);	

	InitScrollTiles(0, 255, tiles_menu, 3);
	if (Menu_Mode == 0)InitScroll(map_plogoWidth, map_plogoHeight, map_plogoPLN0, 0, 0, 2, map_plogoPLN1);
	if (Menu_Mode == 2){
		CP_LoadMusic(6,1);
		InitScroll(map_menuWidth, map_menuHeight, map_menuPLN0, 0, 0, 3, map_menuPLN1);
	}
	
	SHOW_BKG;
	
	//Load bkg-tile animations
	
	LOAD_MAP_ANIM(&Bkg_items[0],3, 3, 4, map_menu_anim_asteroid, 3);
	LOAD_MAP_ANIM(&Bkg_items[1], 2, 3, 4, map_menu_anim_ball, 3);
	//Ball->state = 0;
	LOAD_TILE_ANIM(&Tile_items[0], 1, 4, tile_menu_anim_star, 3);
	LOAD_TILE_ANIM(&Tile_items[1], 1, 4, tile_menu_anim_star2, 3);	
	
	if (Menu_Mode == 0) CP_LoadMusic(6,0);
	M = 0;
}

void Update_STATE_MENU() {
	switch (Menu_Mode){
		case 0:
			if(M == 250){
				InitScroll(map_flogoWidth, map_flogoHeight, map_flogoPLN0, 0, 0, 3, map_flogoPLN1);
				Menu_Mode = 1;
				CP_LoadMusic(6,1);
			}
			M++;
		break;
		case 1:
			if(KEY_PRESSED(J_START)) {M = 0; Menu_Mode = 2;}
		break;
		case 2: // To Main Menu
			InitScroll(map_menuWidth, map_menuHeight, map_menuPLN0, 0, 0, 3, map_menuPLN1);
			SpriteManagerAdd(SPRITE_SHIP, 160+16, 3*8);
			SpriteManagerAdd(SPRITE_UFO, -16, 10*8);
			SpriteManagerAdd(SPRITE_ARROW, 80, 80);
			Menu_Mode = 3;
		break;
///////////////////////////////////////////
		case 3: //Main Menu
			
			//ANIMATE BKG
			MAP_ANIMATE(&Bkg_items[0], 14, 2, 8);
			MAP_ANIMATE(&Bkg_items[1], 8, 10, 20);
			
			//if(KEY_PRESSED(J_B)) Menu_Mode = 2;
			
		break;
/////////////////////////////////////////////	
		case 4: //Scroll to info
			if (M == 18*8) Menu_Mode = 5;
			MoveScroll(0,M);
			M++; 			
		break;
		case 5: //Info
			if(KEY_PRESSED(J_B))Menu_Mode = 6;
			
			//ANIMATE BKG
			MAP_ANIMATE(&Bkg_items[0], 0, 0, 8);
			MAP_ANIMATE(&Bkg_items[1], 1, 25, 20);			
		break;
		case 6: //Back to Main
			if (M == 0){
				Menu_Mode = 3;
				SpriteManagerAdd(SPRITE_UFO, -16, 3*8);
				SpriteManagerAdd(SPRITE_SHIP, 160+16, 10*8);
				SpriteManagerAdd(SPRITE_ARROW, 80, 80);
			}
			MoveScroll(0,M);
			M--; 			
		break;
		case 7:
			SCX_REG++;
		break;
	}
	
	//ANIMATE STARS 
	TILE_ANIMATE(&Tile_items[0], 100, 8);
	TILE_ANIMATE(&Tile_items[1], 98, 5);		
	
	
	//if(KEY_PRESSED(J_A)) {
    //   SetState(STATE_LEVEL1);
    //}
}
