

//CP
void CP_LoadMusic(UINT8 bank, int song);
void CP_StopMusic();


