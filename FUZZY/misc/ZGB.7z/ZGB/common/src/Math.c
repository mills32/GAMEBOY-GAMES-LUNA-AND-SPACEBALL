#include "Math.h"

INT16 DespRight(INT16 a, INT16 b) {
	return a >> b;
}