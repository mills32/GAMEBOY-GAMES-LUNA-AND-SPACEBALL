#include "BankManager.h"

DECLARE_STACK(bank_stack, N_PUSH_BANKS);