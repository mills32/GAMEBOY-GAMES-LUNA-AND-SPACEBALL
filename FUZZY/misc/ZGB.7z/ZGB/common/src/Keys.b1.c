#pragma bank=1
#include "Keys.h"

UBYTE previous_KEYS = 0;
UBYTE keys = 0;