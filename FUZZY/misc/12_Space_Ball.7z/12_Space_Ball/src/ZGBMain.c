#include "ZGBMain.h"

//include all h resources here
#include "StateMenu.h"
#include "StateLevel1.h"

//Load this scene
UINT8 next_state = STATE_MENU;

SET_N_STATES(N_STATES);
SET_N_SPRITE_TYPES(N_SPRITE_TYPES);

UINT8 SCENE = 1; 

//Init these scenes
void InitStates() {
	INIT_STATE(STATE_MENU);
	INIT_STATE(STATE_LEVEL1);
}

void InitSprites() {

}

#include "Math.h"
UINT8 GetTileReplacement(UINT8* tile_ptr, UINT8* tile) {
	if(current_state == STATE_LEVEL1) {
		if(U_LESS_THAN(255 - (UINT16)*tile_ptr, N_SPRITE_TYPES)) {
			*tile = 0;
			return 255 - (UINT16)*tile_ptr;
		}
		*tile = *tile_ptr;
	}
	return 255u;
}

const BYTE datafill[] =
{
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00


};