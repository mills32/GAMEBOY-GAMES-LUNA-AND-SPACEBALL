#ifndef SPRITE_ARROW_H
#define SPRITE_ARROW_H

#include "main.h"

DECLARE_SPRITE(SPRITE_ARROW);

#endif