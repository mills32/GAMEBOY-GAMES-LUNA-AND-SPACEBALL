#ifndef SPRITE_UFO_H
#define SPRITE_UFO_H

#include "main.h"

DECLARE_SPRITE(SPRITE_UFO);

#endif