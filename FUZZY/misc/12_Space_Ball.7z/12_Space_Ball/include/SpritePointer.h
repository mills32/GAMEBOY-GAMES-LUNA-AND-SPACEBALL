#ifndef SPRITE_POINTER_H
#define SPRITE_POINTER_H

#include "main.h"

DECLARE_SPRITE(SPRITE_POINTER);

#endif