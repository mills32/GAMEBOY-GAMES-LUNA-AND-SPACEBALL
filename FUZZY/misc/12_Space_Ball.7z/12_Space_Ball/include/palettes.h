#include <gb/gb.h> 

extern const UWORD sprites_PAL[];
extern const UWORD menu_PAL[];
extern const UWORD level1_PAL[];
