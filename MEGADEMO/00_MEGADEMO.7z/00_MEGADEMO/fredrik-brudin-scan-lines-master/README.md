# Fredrik Brudin - Scan Lines

## Description

From the tutorial "How to mess with scan lines to create visual effects" 
published at [gbdk-developers.com](http://gbdk-developers.com/)

## Original author

Fredrik Brudin
