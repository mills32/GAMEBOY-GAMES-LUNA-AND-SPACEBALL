
 In order to add your own picture into a PICT*.S do
 the following steps:

1) Get a graphic file and save it under the name 'test.tga' as
   a 160x144, 24bit, uncompressed TGA graphic file.

1) Get the Gameboy HiColour Convertor for Windows by Glen Cook.

2) Load 'test.tga', convert, and then Export Data.

3) The resulting test.til,test.atr,test.map, & test.pal files need
   to be converted from binary to ascii for including in a .s file.
   To do this get the program B2X for DOS/*nix from Devrs.Com.
   Check under GameBoy/Apps/Misc or do a site search for B2X.

4) Use the -p -d options in B2X & do the following in DOS:

   Do the following in DOS to figure out your B2X version:
     b2x -h

   If you have B2X v1.0 do this:
     b2x -n TestTil -d -p test.til test.t
     b2x -n TestAtr -d -p test.atr test.a
     b2x -n TestMap -d -p test.map test.m
     b2x -n TestPal -d -p test.pal test.p

   If you have B2X v1.1 or later do this instead:
     b2x -n TestTil -d -p <test.til >test.t
     b2x -n TestAtr -d -p <test.atr >test.a
     b2x -n TestMap -d -p <test.map >test.m
     b2x -n TestPal -d -p <test.pal >test.p

5) Do the following in DOS:

     copy test.t+test.a+test.m+test.p test.s

6) Using your favorite text editor add the following lines
   to the beginning of test.s:

     .area _CODE_1
     .dw TestTil
     .dw TestAtr
     .dw TestMap
     .dw TestPal

7) Do the following in DOS:

     copy test.s pict1.s

8) Tha.. tha.. that's all folks.


