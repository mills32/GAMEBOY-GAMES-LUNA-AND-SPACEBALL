#include <gb/gb.h>
#include <gb/drawing.h>
#include <stdio.h>

const UWORD GrayScale[] = {32733,21140,10570,0,};
extern const unsigned char Sprites[];

void DisplayHiclr(char BANK, char KEYMASK);

void HICOLOUR() {DisplayHiclr(8,J_A);}

int v = 0;
void Reset_LCD(){
	wait_vbl_done();
    disable_interrupts();
    DISPLAY_OFF;
     for  (v = 0; v < 255; v++){remove_VBL(v); remove_LCD(v);}
     LCDC_REG =  0x47;
     mode (0xE2);
     move_bkg(0,0);
    DISPLAY_ON;
	SHOW_BKG;
    enable_interrupts();		
}
void INIT(){
   	if (_cpu == 0x11) {set_bkg_palette(0, 8, GrayScale);}
    puts("      GAME BOY  ");	
	delay(3000);
}	

void main(){

    cpu_fast(); //CPU a 8 Mhz
    INIT();
    //DisplayHiclr(9,J_A); //Draw image until A is pressed
	//Reset_LCD();
	while(1){
		DisplayHiclr(3,J_A); 
        wait_vbl_done();
		SCX_REG++;
    }
}
