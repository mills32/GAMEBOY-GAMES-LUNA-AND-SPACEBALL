#include <gb/gb.h>

#define MapSize_x 256
#define MapSize_y 18

extern unsigned int MapPLN0[];
extern unsigned int MapPLN1[];
extern unsigned char MapTile[];

// Background palette colours.
const UWORD backcolours[] =
{
32493,23254,12684,7399,
12159,535,547,32,
901,547,797,337,
32493,901,547,32,
17373,547,6943,32,
32493,797,1328,32,
15317,901,547,32,
31610,32393,32000,32198
};


int v = 0;
UINT16 Tile_Cnt = 0; //TILE count
UINT8 *tile = (int) &MapPLN0+256;
int TY = 0; //Y POS tile
int Scroll = 0; //init Scroll steps
int SCR_X = 0; //
int SCR_Y = 0; //
UINT16 ScrollX = 0; //Tile x

void ZGB_SET_TILE(UINT8 x,UINT8 y, unsigned char *t); 
//scroll map: Scr = 1 - RIGHT; 2 - LEFT; 3 - UP; 4 - DOWN;
void Scroll_Big_Map(int Scr){
	
	int POS_FX = (SCX_REG+164)/8;
    if (Scr == 1){ 
        Tile_Cnt = ScrollX+21;
		if (Tile_Cnt == MapSize_x) {ScrollX = -21; Tile_Cnt = 0;} //reset if reach X limit Working
		 /////////////////////
		for (TY = 0; TY<18;TY++){
            VBK_REG = 0;
			ZGB_SET_TILE(POS_FX ,TY, &MapPLN0+Tile_Cnt); 
    	    //set_bkg_tiles(POS_FX ,TY, 1, 1, (unsigned char *) &MapPLN0+Tile_Cnt);
    		VBK_REG = 1;
			ZGB_SET_TILE(POS_FX ,TY, &MapPLN0+Tile_Cnt);
    	    //set_bkg_tiles(POS_FX,TY, 1, 1, (unsigned char *) &MapPLN1+Tile_Cnt);
    		Tile_Cnt+=MapSize_x;
			VBK_REG = 0;
        }	 
    	ScrollX++;
		Scroll = 0;
    }
}

void main () {
	
	VBK_REG = 0;							
    set_bkg_data(0, 127, MapTile);
	set_bkg_tiles(0, 0, 256, 18, MapPLN0);						
	VBK_REG = 1;
	set_bkg_palette(0, 8, backcolours);
	set_bkg_tiles(0, 0, 256, 18, MapPLN1);		
	VBK_REG = 0;
	while (1) {		
		
		//MOVE
		//SCX_REG+=2;
		
		if (SCR_X == 8){ SCR_X = 0; Scroll = 1;}
		//scroll map: 1 - RIGHT; 2 - LEFT; 
		Scroll_Big_Map(Scroll);
		
		ZGB_SET_TILE(0 ,2, &MapPLN0+256);
		//SCR_X+=1;
		
        wait_vbl_done();
	}
}	
