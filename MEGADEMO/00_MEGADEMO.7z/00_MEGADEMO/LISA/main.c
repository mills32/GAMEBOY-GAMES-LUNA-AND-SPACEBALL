#include <gb/gb.h>
#include "fade.h"
#include "tiles.h"

/* Sprite properties bits 

#define S_PALETTE    0x10U  0x0_U
#define S_FLIPX      0x20U
#define S_FLIPY      0x40U
#define S_PRIORITY   0x80U	0x_0U
*/

extern unsigned char LisaPLN0[];
extern unsigned char LisaPLN1[];
extern unsigned char LisaTiles0[];
extern unsigned char LisaTiles1[];
extern unsigned char LisaSpritesCGB[];
extern unsigned char LisaSprites[];

// Background palette colours.
UWORD INITCOL[] =
{
   0,0,0,996, 
   0,0,0,996,
};

UWORD backcolours[] =
{
32005,32767,1023,0,
19775,32767,1023,0,
32005,32767,19775,0,
32005,32767,1023,0
};


UWORD spritecolours[] =
{
32265,0,3808,3048,
32265,32733,31543,0,
32265,26815,20500,0,
0,0,0,0,
0,0,0,0,
0,0,0,0,
0,0,0,0,
0,0,0,0
};

//_cpu variable: DMG = 0x01;  CGB = 0x11
int A = 0;
int v = 0;
int til = 0;
int HSX1 = 0;
int Wave[] = 
{0,-1,-2,-2,-3,-3,-3,-2,-2,-1,0,1,2,2,3,3,3,2,2,1,
0,-1,-2,-2,-3,-3,-3,-2,-2,-1,0,1,2,2,3,3,3,2,2,1
};
int Frame = 0;

void DrawLisaCGB(){
    wait_vbl_done();	
	DISPLAY_OFF;
	HIDE_BKG;
	SWITCH_ROM_MBC1(5);
	set_bkg_palette(0, 8, backcolours);
	set_sprite_palette(0, 8, spritecolours);
	VBK_REG = 0;	   
	   set_bkg_tiles( 0, 0, 20, 20, LisaPLN0); //maptiles
	VBK_REG = 1;	   
	   set_bkg_tiles( 0, 0, 20, 20, LisaPLN1); //map colours 	
	VBK_REG = 0;
	   set_bkg_data(0, 256, LisaTiles0); //tile bank 1
    VBK_REG = 1;
       set_bkg_data(0x0, 255, LisaTiles1); // tile bank 2	   
	VBK_REG = 0;
		SWITCH_ROM_MBC5(2);
	    set_sprite_data(0, 80, LisaSprites); ///Sprites	
		for (v = 0; v<40;v++){
			set_sprite_tile(v, til);
			til+=2;
		}
    VBK_REG = 1;
	    //for (v = 0x0; v<40;v++) set_sprite_prop(v, S_PRIORITY); 0x8_U
	    for (v = 0; v<40;v++) set_sprite_prop(v, LisaSpritesCGB[v]); //0x0N_
	VBK_REG = 0;
	SHOW_SPRITES;
	SHOW_BKG;
	DISPLAY_ON;	
}

void MoveSprites(){
    //Minicloud
	move_sprite(39,-20+HSX1,60); 

}

void Update_Lisa(){
	if (Frame == 18) Frame = 0;
	SCY_REG = Wave[Frame];
	Frame++;
}

void main () {
	DrawLisaCGB();
	add_VBL(Update_Lisa);
	cpu_fast();

	while (1) {	//main loop	
	
        //MoveSprites();
		if (joypad() & J_A)Fade(backcolours,FadeDirectionTo, FadeColorBlack,50);
		if (joypad() & J_B)Fade(backcolours,FadeDirectionFrom, FadeColorBlack,50);   
		if (joypad() & J_START)Fade(backcolours,FadeDirectionTo, FadeColorWhite,50);
		if (joypad() & J_SELECT)Fade(backcolours,FadeDirectionFrom, FadeColorWhite,50);   
		
		wait_vbl_done();
	}
}
