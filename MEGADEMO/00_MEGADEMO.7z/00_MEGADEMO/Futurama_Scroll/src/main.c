#include <gb/gb.h>

//Carillon Player Functions
void CP_LoadMusic(UINT8 bank,UINT8 sbank,int song);
void CP_UpdateMusic();
void CP_SelectSong(UINT8 song); 
void CP_StopMusic();

void scroll_bkg_tiles(int x,int y); //in asm 
void SET_BKG_DAT(); //in asm 

/* Sprite properties bits = 0x00U 
PALETTE      0x_0_
FLIPX        0x2__
FLIPY        0x4__
BEHIND BKG   0x8_U
*/

extern const unsigned char BKGTile0[];
extern const unsigned char BKGTile1[];

extern const unsigned char ShipTile[];
extern const unsigned char ShipTileCGB[];
extern const unsigned char FinalTile[];
extern const unsigned char MapPLN0[];
extern const unsigned char MapPLN1[];
extern const unsigned char WinPLN0[];
extern const unsigned char WinPLN1[];

extern const unsigned char BKGTile0PAL[];
extern const unsigned char ShipTilePAL[];

const unsigned UINT8 SINE[] = 
{
	0, 2, 4, 6, 8, 9,
	11, 13, 14, 16, 17, 18, 19, 19, 19, 20,
	19, 19, 19, 18, 17, 16, 14, 13, 11, 10,
	8, 6, 4, 2, -1, -3, -5, -7, -9, -11,
	-12, -14, -15, -17, -18, -19, -20, -20, -20, -20,
	-20, -20, -20, -19, -18, -17, -15, -14, -12, -11,
	-9, -7, -5, -3, -1, 2
};
UINT8 v;
UINT8 SPR_X;         //Meta Sprite pos x
UINT8 SPR_Y;         //Meta Sprite pos y
UINT8 SPR;           //Meta Sprite number
UINT8 Map_X;         //Map Scrolling 
UINT8 Map_PosX;      //Map Scrolling
UINT8 Scroll;        //Map Scrolling
UINT8 ScrollX;       //Map Scrolling
UINT16 Tile_Cnt;   //Map Scrolling
UINT8 BSpeed;		   //Parallax Speed
UINT8 PSpeed;		   //Parallax Speed
UINT16 Parallax;	   //Parallax Frame
UINT16 ParaOffset;
UINT8 Shield;
UINT8 Scene;
UINT8 SINEV;       // move background
UINT8 XC;
UINT8 YC;	
UINT8 XP;            //Move Sprites
UINT8 YP; 

void main () {

    v = 0;
	SPR_X = 0;         //Meta Sprite pos x
	SPR_Y = 0;         //Meta Sprite pos y
	SPR = 0;           //Meta Sprite number
	
	Map_X = 0;         //Map Scrolling 
	Map_PosX = 0;      //Map Scrolling
	Scroll = 0;        //Map Scrolling
	ScrollX = 0;       //Map Scrolling
	Tile_Cnt = 0;   //Map Scrolling
	
	BSpeed = 0;		   //BKG Speed
	PSpeed = 0;		   //Parallax Speed
    Parallax = 0;	   //Parallax Frame
	
	Shield = 0;
	
	Scene = 0;
	XC = 0;            // move background
	YC = 0;	
	XP = -120;            //Move Sprites
	YP = 40; 

	SINEV = 0;	
	SWITCH_ROM_MBC5(2);
	disable_interrupts();
    cpu_fast(); //CPU a 8 Mhz
	DISPLAY_OFF;
	HIDE_SPRITES;
	HIDE_BKG;
    HIDE_WIN;
	
	SPRITES_8x16;					// sets sprites to 8x16 mode	
	set_bkg_palette(0, 8, BKGTile0PAL);	
	set_sprite_palette( 0, 8, ShipTilePAL);				// loads the pallete colours
	
	VBK_REG = 0;	// switch to Video Bank 0
        set_bkg_tiles(0, 0, 255, 18, MapPLN0); //Map bkg
		set_win_tiles(0, 0, 11, 18, WinPLN0); 
		set_bkg_data(0, 86, BKGTile0); // tiles0
		set_win_data(0, 47, BKGTile0);
		set_sprite_data(0, 80, ShipTile);	
		for (v = 0; v<40;v++){		
			set_sprite_tile(v, SPR);
			SPR+=2;	
		}		
	VBK_REG = 1;
		set_bkg_tiles(0, 0, 255, 18, MapPLN1);
		set_win_tiles(0, 0, 11, 18, WinPLN1); 
		for (v = 0; v<40;v++)
		set_sprite_prop(v, ShipTileCGB[v]);

	SHOW_SPRITES;
	SHOW_BKG;
	HIDE_WIN;
	DISPLAY_ON;
	enable_interrupts();
	SCX_REG = 0;
	//WX_REG = 168;
	XP = 30;
	
	CP_LoadMusic(4,0,0);

	while (1) {	//main loop	
		
		//BKG
		if (Scene < 2){
			SCX_REG+=2; 
			Map_X+=2;
		}
		//Parallax
     	if (Parallax == 20) Parallax = 0; 
		if (PSpeed == 2){
			ParaOffset = Parallax*200; //(25*8)
			VBK_REG = 0;
			SWITCH_ROM_MBC5(3);
			//if (STAT_REG & 1) 60, 25 
			SET_BKG_DAT(&BKGTile1 + ParaOffset);//(change bkg tiles)
			PSpeed = 0; 
			Parallax++;
			//XP++;
		}
    	PSpeed++;
    	
    	if (SINEV == 60) SINEV = 0;
    	YP = 40 + SINE[SINEV];
		//if (XP =! 40) 
    	
		SINEV++;
    	
    	//SHIP
    	if (Scene < 2){
			SPR = 0;
			for (SPR_Y = 0; SPR_Y<49;SPR_Y+=16){
				for (SPR_X = 0; SPR_X<80;SPR_X+=8){
					move_sprite(SPR, XP+SPR_X, YP+SPR_Y);
					SPR++;
				}
			}
    	}
    	//////////////////////////////////////////
    	//SCROLL
		SWITCH_ROM_MBC5(2);
    	if (Map_X == 8){ Map_X = 0; Scroll = 1;}
    	Map_PosX = (SCX_REG+168)/8;
    	if (Scroll == 1){ 
    		Tile_Cnt = ScrollX+22;
    		if ((Scene == 0) && (Tile_Cnt == 235)) {Scene = 0; ScrollX = -22; Tile_Cnt = 0;} //reset if reach X limit Working
    		if ((Scene == 1) && (Tile_Cnt == 256)) {Scene = 2; } // end scene = 2
    		for (v = 0; v<18;v++){
    			VBK_REG = 0;
    			set_bkg_tiles(Map_PosX,v, 1, 1, (unsigned char *) &MapPLN0+Tile_Cnt);
    			VBK_REG = 1;
    			set_bkg_tiles(Map_PosX,v, 1, 1, (unsigned char *) &MapPLN1+Tile_Cnt);
    			Tile_Cnt+=255;
    		}	 
    		ScrollX++;
    		Scroll = 0;
    	}
    	//////////////////////////////////////////
		
    	if (Shield == 0){
    		//if (joypad() & J_A) XP++;
    	}
  	
    	
    	//Scenes
    	
    	else {
    		if (XP < 100) XP+=2;
    		if (XP == 100){
    			//set_sprite_data(0, 39, FinalTile);
    			XP = 101;
    		}
    		if (WX_REG > 93) WX_REG--;
    		
    	}		
		
		CP_UpdateMusic();
		wait_vbl_done();
	}   
}	

