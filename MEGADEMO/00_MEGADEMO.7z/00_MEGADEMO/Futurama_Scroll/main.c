#include <gb/gb.h>

//Carillon Player Functions
void CP_Init(); //in asm 
void CP_LoadSong(); //in asm 
void CP_UpdateMusic(); //in asm  
void CP_StopSong(); //in asm 

void scroll_bkg_tiles(int x,int y); //in asm 

/* Sprite properties bits = 0x00U 
PALETTE      0x_0_
FLIPX        0x2__
FLIPY        0x4__
BEHIND BKG   0x8_U
*/

extern const unsigned char BKGTile0[];
extern const unsigned char BKGTile1[];
extern const unsigned char BKGTile2[];
extern const unsigned char BKGTile3[];
extern const unsigned char BKGTile4[];
extern const unsigned char BKGTile5[];
extern const unsigned char BKGTile6[];
extern const unsigned char BKGTile7[];
const unsigned char * Futurama_AnimBKG[] = {
	BKGTile0,BKGTile1,BKGTile2,BKGTile3,
	BKGTile4,BKGTile5,BKGTile6,BKGTile7,
	0x0000
};
extern const unsigned char ShipTile[];
extern const unsigned char ShipTileCGB[];
extern const unsigned char FinalTile[];
extern const unsigned char MapPLN0[];
extern const unsigned char MapPLN1[];
extern const unsigned char WinPLN0[];
extern const unsigned char WinPLN1[];

UWORD backcolours[] =
{
30687,12684,6342,1057,
32703,31484,31262,1024,
29630,6463,122,1024,
32767,29919,13357,1024,
17246,572,1328,1024,
32767,8166,1473,0,
32702,32237,22528,0,
32733,12684,14798,0
};

// Sprite palletes colours. There are eight possible palletes to choose from.
UWORD spritecolours[] =
{	
32767,24552,11904,0,
32767,24552,8607,0,
32767,8607,32389,0,
32767,24552,11904,0,
32767,24552,32389,0,
32767,18302,669,0,
32767,32389,11904,0,
32767,24552,23254,0,
};

void main () {
    const unsigned char SINE[] = 
	{
		0, 2, 4, 6, 8, 9,
11, 13, 14, 16, 17, 18, 19, 19, 19, 20,
19, 19, 19, 18, 17, 16, 14, 13, 11, 10,
8, 6, 4, 2, -1, -3, -5, -7, -9, -11,
-12, -14, -15, -17, -18, -19, -20, -20, -20, -20,
-20, -20, -20, -19, -18, -17, -15, -14, -12, -11,
-9, -7, -5, -3, -1, 2
	};
    int v = 0;
	int SPR_X = 0;         //Meta Sprite pos x
	int SPR_Y = 0;         //Meta Sprite pos y
	int SPR = 0;           //Meta Sprite number
	
	int Map_X = 0;         //Map Scrolling 
	int Map_PosX = 0;      //Map Scrolling
	int Scroll = 0;        //Map Scrolling
	int ScrollX = 0;       //Map Scrolling
	UINT16 Tile_Cnt = 0;   //Map Scrolling
	
	int PSpeed = 0;		   //Parallax Speed
    int Parallax = 0;	   //Parallax Frame
	
	int Shield = 0;
	
	int Scene = 0;
	int XC = 0;            // move background
	int YC = 0;	
	int XP = 8;            //Move Sprites
	int YP = 40; 
	

	int SINEV = 0;	
	SWITCH_ROM_MBC5(2);
	disable_interrupts();
    cpu_fast(); //CPU a 8 Mhz
	DISPLAY_OFF;
	HIDE_SPRITES;
	HIDE_BKG;
    HIDE_WIN;
	
	SPRITES_8x8;					// sets sprites to 8x16 mode	
	set_bkg_palette(0, 8, backcolours);	
	set_sprite_palette( 0, 8, spritecolours);				// loads the pallete colours
	
	VBK_REG = 0;	// switch to Video Bank 0
        set_bkg_tiles(0, 0, 256, 18, MapPLN0); //Map bkg
		set_win_tiles(0, 0, 11, 18, WinPLN0); 
		set_bkg_data(0, 52, Futurama_AnimBKG[0]); // tiles0
		set_win_data(0, 47, Futurama_AnimBKG[0]);
		set_sprite_data(0, 39, ShipTile);	
		for (v = 0; v<40;v++)		
		set_sprite_tile(v, v);		
	VBK_REG = 1;					
	    set_bkg_tiles(0, 0, 256, 18, MapPLN1);
		set_win_tiles(0, 0, 11, 18, WinPLN1); 
		for (v = 0; v<40;v++)
		set_sprite_prop(v, ShipTileCGB[v]);
	    //for (v = 20; v<40;v++)
        //set_sprite_prop(v,0x80U);	
							
	SHOW_SPRITES;
	SHOW_BKG;
	SHOW_WIN;
	DISPLAY_ON;
	enable_interrupts();
	SCX_REG = 0;
	WX_REG = 168;
	XP = 60;
	
	CP_Init();
    CP_LoadSong();
	while (1) {	//main loop	
		
		SWITCH_ROM_MBC5(2);
		//Parallax
     	if (Parallax == 8) Parallax = 0;  
    	VBK_REG = 0;	
    	set_bkg_data(0, 4, Futurama_AnimBKG[Parallax]);	//(change bkg tiles)
    	if (PSpeed == 2){PSpeed = 0; Parallax++;}
    	PSpeed++;
		
    	//BKG
    	if (Scene < 2) SCX_REG+=2; 
    	
    	if (SINEV == 60) SINEV = 0;
    	YP = 60+ SINE[SINEV];
    	SINEV++;
    	
    	//SHIP
    	if (Scene < 2){
    	SPR = 0;
    	for (SPR_Y = 0; SPR_Y<40;SPR_Y+=8){
    		for (SPR_X = 0; SPR_X<64;SPR_X+=8){
    			if (SPR < 35){
    				move_sprite(SPR, XP+SPR_X, YP+SPR_Y); 
    				SPR++;
    			}
    		}
    	}
    	}
    	//////////////////////////////////////////
    	//SCROLL
    	if (Map_X == 8){ Map_X = 0; Scroll = 1;}
    	Map_PosX = (SCX_REG+168)/8;
    	if (Scroll == 1){ 
    		Tile_Cnt = ScrollX+22;
    		if ((Scene == 0) && (Tile_Cnt == 236)) {Scene = 0; ScrollX = -22; Tile_Cnt = 0;} //reset if reach X limit Working
    		if ((Scene == 1) && (Tile_Cnt == 257)) {Scene = 2; } // end scene = 2
    		for (v = 0; v<18;v++){
    			VBK_REG = 0;
    			set_bkg_tiles(Map_PosX,v, 1, 1, (unsigned char *) &MapPLN0+Tile_Cnt);
    			VBK_REG = 1;
    			set_bkg_tiles(Map_PosX,v, 1, 1, (unsigned char *) &MapPLN1+Tile_Cnt);
    			Tile_Cnt+=256;
    		}	 
    		ScrollX++;
    		Scroll = 0;
    	}
    	//////////////////////////////////////////
    	
    	if (Shield == 0){
    		//if (joypad() & J_A) XP++;
    	}
    	
    	
    	//Scenes
    	if (Scene < 2)Map_X+=2;
    	else {
    		if (XP < 100) XP+=2;
    		if (XP == 100){
    			set_sprite_data(0, 39, FinalTile);
    			XP = 101;
    		}
    		if (WX_REG > 93) WX_REG--;
    		
    	}		
		CP_UpdateMusic();
		wait_vbl_done();
	}   
}	

