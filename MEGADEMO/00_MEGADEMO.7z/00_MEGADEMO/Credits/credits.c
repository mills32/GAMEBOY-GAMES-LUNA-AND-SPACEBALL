#include <gb/gb.h>

#define MapSize_x 256
#define MapSize_y 18

extern unsigned int MapPLN0[];
extern unsigned int MapPLN1[];
extern unsigned char MapTile[];
extern unsigned char CreditSprites[];

//Carillon Player Functions
void CP_Init(); //in asm 
void CP_LoadSong(); //in asm 
void CP_UpdateMusic(); //in asm  
void CP_StopSong(); //in asm 

// Background palette colours.
const UWORD backcolours[] =
{
0,32767,9513,22624,
0,32767,9513,22624,
0,32767,9513,22624,
0,32767,9513,22624,
0,32767,9513,22624,
0,32767,9513,22624,
0,32767,9513,22624,
0,32767,9513,22624
};

// Sprites palette colours.
const UWORD spritecolours[] =
{
0,28606,6047,410
};

int v = 0;
UINT16 Tile_Cnt = 0; //TILE count

int TX = 0; //Y POS tile
int Scroll = 0; //init Scroll steps
int SCR_X = 0; //
int SCR_Y = 0; //
int POS_FY = 0;
UINT16 ScrollY = 0; //Tile x
int Speed = 0;
int Spri = 0;

void main () {
	
	VBK_REG = 0;							
    set_bkg_data(0, 256, MapTile);
	set_bkg_tiles(0, 0, 20, 128, MapPLN0);						
	VBK_REG = 1;
	set_bkg_palette(0, 8, backcolours);
	set_bkg_tiles(0, 0, 20, 128, MapPLN1);
	set_sprite_palette(0, 2, spritecolours);
	VBK_REG = 0;
	SPRITES_8x16;
	set_sprite_data(0, 14, CreditSprites); ///Sprites	
	for (v = 0; v<7;v++){
		set_sprite_tile(v, Spri);
		Spri+=2;
	}
	
	Tile_Cnt = ScrollY+380;
	
	CP_Init();
    CP_LoadSong();
	
	SHOW_SPRITES;
	
	while (1) {		
		
		//MOVE
		//if (Speed == 2) SCY_REG-=1;
		
		if (SCR_Y == 8){ 
			SCR_Y = 0; 
	        POS_FY = (SCY_REG+148)/8;
            
	        if (ScrollY == 128-20) {ScrollY = 0; Tile_Cnt = 0;} //reset if reach X limit Working
                VBK_REG = 0;
                set_bkg_tiles(0,POS_FY , 20, 1, (unsigned char *) &MapPLN0+Tile_Cnt);
            	VBK_REG = 1;
                set_bkg_tiles(0,POS_FY, 20, 1, (unsigned char *) &MapPLN1+Tile_Cnt);
            	Tile_Cnt+=20;
            ScrollY++;
		}
		if (Speed == 4){Speed = 0; SCR_Y+=1; SCY_REG++;}
				
		
		
		//Sprites
		move_sprite(0,20,20); move_sprite(1,28,20); move_sprite(2,36,20); 
		
		Speed++;
		
		CP_UpdateMusic();
        wait_vbl_done();
	}
}	
