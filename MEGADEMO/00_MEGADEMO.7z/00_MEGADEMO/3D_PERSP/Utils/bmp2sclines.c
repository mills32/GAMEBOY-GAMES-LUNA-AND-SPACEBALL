

// BitMap to X pos scanlines for GameBoy fake perspective


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

//COLORS FF C0 00
int main(int argc, char **argv) {
	int i;
	
	FILE *streamIn;
	FILE *fout;
	streamIn = fopen("bitmap_VRAM.data", "rb");
	fout = fopen("persp3d_scanlines.b3.c", "w");
	
	if (streamIn == (FILE *)0){
	printf("File opening error ocurred. Exiting program.\n");
	exit(0);
	}

	fseek(streamIn, 0, SEEK_END);
	int size = ftell(streamIn);
	rewind(streamIn);

	static int data[10000000];
	
	//CONVERT TO SCANLINES in output file
	int linelen = 0;
	int linenum = 0;
	int pos = 0;
	int count = 0;
	fprintf(fout,"//BITMAP to X SCANLINES\n\n");
	fprintf(fout,"#include <gb/gb.h>\n\n\n");
	fprintf(fout,"const unsigned char persp3d_scanlines");
	fprintf(fout,"[] =\n");
	fprintf(fout,"{\n\t");
	
	//GET R DATA
	for(int i = 0; i < size; i+=3) {
		pos++;
		data[pos-1] = fgetc(streamIn);
		fgetc(streamIn);
		fgetc(streamIn);
	}
	
	//CONVERT TO SCANLINES
	pos = 0;
	linelen = 0;
	int array_w = 0;
	int get_pos = 1;
	int init_pos[144] = {0};
	
	for(int i = 0; i < size; i++) {
		pos++;
		linelen++; //position in line
		if (data[pos-1] == 0xFF){ //White 
			fprintf(fout,"%d, ",(linelen-1));
			array_w++;
			pos = pos + (159-(linelen-1));
			linelen = 0;
			count++;
		}
		
		if (data[pos-1] == 0xC0){ //FIX first frame  
			fprintf(fout,"%d, ",160);
			array_w++;
			pos = pos + (159-(linelen-1));
			linelen = 0;
			count++;
		}
		
		if (linelen == 160){//black
			linelen = 0;
			fprintf(fout,"%d, ",0);
			array_w++;
			count++;
		}
		// break after every 10th number 
		if(array_w == 10) {
			array_w = 0;
			fprintf(fout,"\n\t");
		}
		if (count == size/3/160) break;
	}
	
	
	fprintf(fout,"\n};");
	
	fclose(streamIn);
	fclose(fout);
	
	printf("filesize = %d ", size);
}