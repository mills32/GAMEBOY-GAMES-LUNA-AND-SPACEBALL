
/** Signed eight bit.
 */
typedef char          	INT8;
/** Unsigned eight bit.
 */
typedef unsigned char 	UINT8;
/** Signed sixteen bit.
 */
typedef UINT8		BYTE;

