#include <gb/gb.h>
#include "fade.h"
//40 frames / bank  (1 frame = 1 planes of 20x18 tiles)
//used just one palette plane

extern const unsigned char RotoCol1[];
extern const unsigned char RotoTiles[];
extern const unsigned char RotoMap1[];
extern const unsigned char RotoMap2[];
extern const unsigned char RotoMap3[];
extern const unsigned char RotoMap4[];

const const unsigned char * RotoMap[] = {
RotoMap1,RotoMap2,RotoMap3,RotoMap4,
0x0000
};
extern const UWORD RotoTilesPAL[];


int v = 0;
UINT8 Roto_Speed;
UINT16 Roto_Tile_Pos;
UINT8 Frame;
UINT8 rbank;
UINT8 RotoP_Speed;


const UWORD RotoColor1[] = 
{
	32767,5695 ,20083,0,
	32767,32034,20083,0,
	32767,32137,20083,0,
	32767,31278,20083,0,
	32767,31411,20083,0,
	32767,31511,20083,0,
	32767,31611,20083,0,
	32767,32767,20083,0,
};
const unsigned char * RotoPals[] = {RotoTilesPAL,RotoColor1,0x0000};

void CP_LoadMusic(UINT8 bank,UINT8 sbank,int song);
void CP_UpdateMusic();
void CP_SelectSong(UINT8 song); 
void CP_StopMusic();

void RotoMA() {
	cpu_fast();
    set_bkg_palette(0, 8, RotoPals[0]);
	set_bkg_data(0, 88, RotoTiles);
	rbank = 4; //first bank
	VBK_REG = 1; //palette plane
		set_bkg_tiles(0, 0, 20, 18, RotoCol1);
	VBK_REG = 0;	
		SWITCH_ROM_MBC1(rbank);
		set_bkg_tiles(0, 0, 20, 18, RotoMap[0]);	  
    DISPLAY_ON;
	SHOW_BKG;
	//Fade(RotoTilesPAL,FadeDirectionFrom, FadeColorBlack,50);
	Roto_Speed = 0;
	RotoP_Speed = 0;
	Roto_Tile_Pos = 0;
	Frame = 0;
	CP_LoadMusic(2,0,0);
	
	
	
}

void main(){
    RotoMA();
	
	disable_interrupts();
	enable_interrupts();
	
	//TMA_REG = 120;
	//TAC_REG = 0x04U;
	
	//set_interrupts(TIM_IFLAG);
	
	while(1) {	//main loop	
		CP_UpdateMusic();
		SWITCH_ROM_MBC1(0);
		if(RotoP_Speed == 2){
			set_bkg_palette(0, 8, RotoPals[1]);
			RotoP_Speed++;
		}
		if(RotoP_Speed == 5){
			set_bkg_palette(0, 8, RotoPals[0]); 
			
			RotoP_Speed = 0;
		}
		
		if(Roto_Speed == 2){
			if (Frame == 40) {Frame = 0; Roto_Tile_Pos = 0; rbank++;}
			if ((rbank == 7) && (Frame == 39)) {
				Frame = 0; 
				Roto_Tile_Pos = 0; 
				rbank = 4;
				RotoP_Speed++;
			}
			
			SWITCH_ROM_MBC1(rbank);
			VBK_REG = 0;	
				set_bkg_tiles(0, 0, 20, 18, RotoMap[rbank-4]+Roto_Tile_Pos);	
			
			Roto_Tile_Pos+= 360;
			Frame++;
			Roto_Speed = 0;
		}
		Roto_Speed++;
		wait_vbl_done();
	}	
}
