#include <gb/gb.h>

/* Sprite properties bits = 0x00U 
PALETTE      0x_0_
FLIPX        0x2__
FLIPY        0x4__
BEHIND BKG   0x8_U
*/

extern const unsigned char MapTile0[];
extern const unsigned char MapTile1[];
extern const unsigned char MapTile2[];
extern const unsigned char MapTile3[];
extern const unsigned char MapTile4[];
extern const unsigned char MapTile5[];
extern const unsigned char GameTile[];
extern const unsigned char GameTileCGB[];
extern const unsigned char MapPLN0[];
extern const unsigned char MapPLN1[];

UWORD backcolours[] =
{
27482,1543,31865,994,
27482,741,31865,994,
27482,741,31865,994,
27482,741,31865,994,
27482,741,31865,994,
32767,5153,21140,32101
};

// Sprite palletes colours. There are eight possible palletes to choose from.
UWORD spritecolours[] =
{	
32767,19457,32201,32767,
32767,19457,32201,31571,
833,19457,32201,31571,
833,31676,32201,31571,
32767,19457,32201,2048,
32767,5153,21140,32101,
32767,12684,21239,90
};


void main () {
	
    int SINE[] = {1,1,1,1,2,3,4,5,6,7,-7,-6,-5,-4,-3,-2,-1,-1,-1,-1,0};
    int v = 0;
	int XC = 0;             // move background
	int YC = 0;	
	int XP = 168;             // move background
	int YP = 40;  //GAMEBOY
	int XCH = 0; //CHIP
	int YCH = 30;
	int Timer = 0;
	int SPEED = 0;

	int SINEV = 0;
	
	disable_interrupts();
    cpu_fast(); //CPU a 8 Mhz
	DISPLAY_OFF;
	HIDE_SPRITES;
	HIDE_BKG;
    HIDE_WIN;
	
	SPRITES_8x8;					// sets sprites to 8x16 mode	
	set_bkg_palette(0, 5, backcolours);	
	set_sprite_palette( 0, 8, spritecolours);				// loads the pallete colours
	
	VBK_REG = 0;	// switch to Video Bank 0
        set_bkg_tiles(0, 0, 32, 18, MapPLN0); //Map bkg
		set_bkg_data(0, 19, MapTile0); // tiles0	
		set_sprite_data(0, 39, GameTile);	
		for (v = 0; v<40;v++)		
		set_sprite_tile(v, v);		
	VBK_REG = 1;					
	    set_bkg_tiles(0, 0, 32, 18, MapPLN1);
		for (v = 0; v<40;v++)
		set_sprite_prop(v, GameTileCGB[v]);
	    //for (v = 20; v<40;v++)
        //set_sprite_prop(v,0x80U);	
							
	SHOW_SPRITES;
	SHOW_BKG;
	DISPLAY_ON;
	enable_interrupts();
	while (1) {	//main loop	
	
		//ANIMATED BKG
		move_bkg(XC, 0);

		//FONTS (GBC TEST)

        move_sprite(32,20+3*XP,126);
		move_sprite(33,28+3*XP,126);
		move_sprite(34,36+3*XP,126);
		
		move_sprite(35,52+3*XP,126);
        move_sprite(36,60+3*XP,126);
		move_sprite(37,68+3*XP,126);
		move_sprite(38,76+3*XP,126);
	    

		if (XP == -16) YCH = YCH +20;
	   //Move Chip
        move_sprite(24,XCH,YCH);
		move_sprite(25,8+XCH,YCH);
		move_sprite(26,XCH,8+YCH);
		move_sprite(27,8+XCH,8+YCH);

	   //SINE
       if (SINEV == 21) SINEV = 0;	   

	    YP = YP + SINE[SINEV];
	   // move GAMEBOY SPRITES
				
		move_sprite(0, XP, YP); move_sprite(2, XP+8, YP); 
		move_sprite(8, XP+16, YP); move_sprite(10, XP+24, YP); 

		move_sprite(1, XP, YP+8); move_sprite(3, XP+8, YP+8); 
		move_sprite(9, XP+16, YP+8); move_sprite(11, XP+24, YP+8); 

		move_sprite(4, XP, YP+16); move_sprite(6, XP+8, YP+16); 
		move_sprite(12, XP+16, YP+16); move_sprite(14, XP+24, YP+16); 

		move_sprite(5, XP, YP+24); move_sprite(7, XP+8, YP+24); 
        move_sprite(13, XP+16, YP+24); move_sprite(15, XP+24, YP+24); 		

		move_sprite(16, XP, YP+32); move_sprite(18, XP+8, YP+32); 
        move_sprite(20, XP+16, YP+32); move_sprite(22, XP+24, YP+32); 	

		move_sprite(17, XP, YP+40); move_sprite(19, XP+8, YP+40); 
        move_sprite(21, XP+16, YP+40); move_sprite(23, XP+24, YP+40); 		
        
        if (SPEED == 3) {
			SPEED = 0;		
		    Timer +=1;XC +=1;XP +=1;XCH -=2; SINEV +=1;
        }			
		SPEED++;
		
		if (Timer == 6){	
		Timer = 0; 
		}
		//Animate
 		if (Timer == 0){  
	    VBK_REG = 0;	
		set_bkg_data(0, 19, MapTile0);	//(change bkg tiles)
        }		
 		if (Timer == 1){  
	    VBK_REG = 0;	
		set_bkg_data(0, 19, MapTile1);	//(change bkg tiles)
        }
 		if (Timer == 2){  
	    VBK_REG = 0;	
		set_bkg_data(0, 19, MapTile2);	//(change bkg tiles)
        }		

 		if (Timer == 3){  
	    VBK_REG = 0;	
		set_bkg_data(0, 19, MapTile3);	//(change bkg tiles)
        }		
 		if (Timer == 4){  
	    VBK_REG = 0;	
		set_bkg_data(0, 19, MapTile4);	//(change bkg tiles)
        }
 		if (Timer == 5){  
	    VBK_REG = 0;	
		set_bkg_data(0, 19, MapTile5);	//(change bkg tiles)
        }
		
        wait_vbl_done();
	}   
}	

