#include <gb/gb.h>
#include <stdio.h>
#include <gb/drawing.h>

extern const unsigned char Intro_Text_Map[];
extern const unsigned char Intro_Text_Tiles[];

UWORD introcolours[] = 
{
31607,32733,19026,0,	
31607,1013,555,0,	
};

void disable_APA(){
	int v;
	for  (v = 0; v < 255; v++){remove_VBL(v); remove_LCD(v);}
	LCDC_REG =  0x07;
	mode (0xE2);
}

void main () {

	int DX = 0;
	int Mode = 0; int PY = 20;
    int v = 0;

	DISPLAY_ON;
	SHOW_BKG;
    set_bkg_palette(0, 8, introcolours);

//==============================================  
	while (1) {	
	  if (Mode == 0){ 
		
		Mode = 1;
		gotogxy(10,10);
		gprint("LOADING");
	  }
	  if (Mode == 1){
         color(3, 3, M_NOFILL);		  
            line(20+DX,76,20+DX,84);
		 color(2, 2, M_NOFILL);	
            box(19,75,141,85,M_NOFILL);			
		 if (DX == 120)Mode = 2;
		 DX++;
      }		
	  
	  if (Mode == 2){}	  
 	
	}
}
	
const unsigned char Intro_Text_Map[] =
{
	0x00,0x00
};

const unsigned char Intro_Text_Tiles[] =
{
	0x00,0x00
};
