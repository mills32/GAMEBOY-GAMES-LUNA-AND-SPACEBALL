/*
    ZOLIG MEGADEMO
	
*/
#include <gb/gb.h>
#include <stdio.h>
#include <gb/drawing.h>

UWORD Simple_palette[] = {0,31,992,32767}; //BLACK, RED, GREEN, WHITE
UWORD Grscale[] = {32733,21140,12684,0};

extern const unsigned char Intro_Map[];

void Reset_LCD(){ //It works!!!
	int v;
	for  (v = 0; v < 255; v++){remove_VBL(v); remove_LCD(v);}
	LCDC_REG =  0x07;
	mode (0xE2);
}

void main(void){
	int DX = 0;
	int Mode = 0;
    int v = 0;
	mode(get_mode() | M_NO_INTERP | M_NO_SCROLL);
	if(_cpu == 0x01) {
	printf("                    ");
	printf("                    ");
	printf("                    ");
    printf("      WARNING!!     ");
	printf("                    ");
    printf("     Only for GBC   ");
	printf("                    ");
	printf("                    ");
	printf("                    ");
	printf("Do not get angry DMG");
	printf("                    ");
	printf("  still love you :) ");
	printf("                    ");
	Mode = -20;
	}
	if(_cpu == 0x11) {// if CGB
	set_bkg_palette(0, 1, Simple_palette); 	
	
	gprint("                    ");
	color(1, 0, M_FILL);
    gprint("      WARNING!!     ");
	gprint("                    ");
	gprint("                    ");
	color(3, 0, M_FILL);
    gprint(" Program techniques ");
    gprint(" used here are well ");
    gprint(" known, so the goal ");
    gprint(" is not to show any ");
    gprint(" original code.     ");
	gprint("                    ");
	gprint(" This demo was just ");
	gprint(" made to be:        ");
	gprint("                    ");
	color(2, 0, M_FILL);
	gprint("  - cute            "); 
	gprint("  - colourfull      ");
    gprint("                    ");
	gprint("    (A) to continue ");	
	
	waitpad(J_A);
	gotogxy(0,0);
	
	gprint("                    ");
	color(2, 0, M_FILL);
    gprint("      THANKS!!      ");
	gprint("                    ");
	gprint("                    ");
	color(3, 0, M_FILL);
    gprint("                    ");
	gprint(" Thanks to creators ");
    gprint(" of the resources & ");
    gprint(" program techniques ");
    gprint(" I used for this.   ");
	gprint("                    ");
	gprint(" And thanks to the  ");
	gprint(" Game Boy for being ");
	gprint(" so");
	color(2, 0, M_FILL);
	gprint(" cute            ");
	gprint("                    ");
	color(3, 0, M_FILL);	
	gprint("       MILLS  2018  ");
    gprint("                    ");
	gprint("  PRESS ");
	color(2, 0, M_FILL);
	gprint("A");	
	color(3, 0, M_FILL);
	gprint(" TO START  ");
	
	waitpad(J_A);
	gotogxy(0,0);
	
	Reset_LCD();
	set_bkg_palette(0, 1, Grscale); 
	
	}
//==============================================  
	while (1) {	
	  if (Mode == 0){
		DISPLAY_OFF;
		HIDE_BKG;
		draw_image(Intro_Map);
		gotogxy(1,6);
		color(3, 2, M_FILL);
		gprint("LOADING...");
		Mode = 1;
		DISPLAY_ON;
		SHOW_BKG;
	  }
	  if (Mode == 1){
		 color(0, 0, M_NOFILL);		  
            line(32+DX,72,32+DX,87);
		 /////
		 if (DX == 0){
			color(3, 2, M_NOFILL);
		 	gotogxy(4,12);
		    gprint("Meta code   ");
	     }
		 if (DX == 30){	
			color(3, 2, M_NOFILL);
		 	gotogxy(4,12);
		    gprint("4D pixels   ");
	     }
		 if (DX == 40){	
			color(3, 2, M_NOFILL);
		 	gotogxy(4,12);
		    gprint("N' dimensions");
	     }
		 if (DX == 70){
			color(3, 2, M_FILL);
			gotogxy(4,12);
		    gprint("ERROR:");
			color(3, 2, M_FILL);
			gprint("      ");
			color(3, 2, M_FILL);
		 	gotogxy(4,13);
		    gprint("COLIDING BRANES");
			delay(2000);
	     }
		 if (DX == 119){
			color(3, 2, M_NOFILL);
			gotogxy(2,7);
		    gprint("CRITICAL EVENT!!");
			color(1, 0, M_NOFILL);
		 	gotogxy(1,12);
		    gprint("GENER'TIN. UNIVE$S");
			delay(2000);
	     }	
		 if (DX == 128-32) Mode = 2;
		 set_bkg_palette(0, 1, Grscale); 
		 delay(60);
		 wait_vbl_done();
		 DX++;
      }		
	  if (Mode == 2){
		  SCX_REG++;
		  if (DX == 2000) {DISPLAY_OFF; } //Go to next program
		  DX++;
	  } 
	  
	  if (Mode == -20); //stay for ever

	}

}
