#include <gb/gb.h>

//100 frames of 144 scanlines in one bank

//Carillon Player Functions
void CP_LoadMusic(UINT8 bank,UINT8 sbank,int song);
void CP_UpdateMusic();
void CP_SelectSong(UINT8 song); 
void CP_StopMusic();

extern const unsigned char Map3DPLN0[];
extern const unsigned char Map3DPLN1[];
extern const unsigned char Map3DTiles[];
extern const UWORD Map3DTilesPAL[];
extern const unsigned char map3d_scanlines[]; 

UINT16 Map3D_Frame = 0; 
UINT8 A = 0;

void Map3D_Load(){
	SWITCH_ROM_MBC1(2);
	cpu_fast(); //CPU a 8 Mhz
	set_bkg_palette(0, 8, Map3DTilesPAL);
	wait_vbl_done();
	
	DISPLAY_OFF;	
	VBK_REG = 0;	   
	   set_bkg_tiles( 0, 0, 20, 25, Map3DPLN0);
	VBK_REG = 1;	   
	   set_bkg_tiles( 0, 0, 20, 25, Map3DPLN1); 
	VBK_REG = 0;
	   set_bkg_data(0, 9, Map3DTiles); 
    DISPLAY_ON;
	
	CP_LoadMusic(4,0,0);
}	

void Map3D_update() {	
	Map3D_Frame+=144; 
	if (Map3D_Frame == 144*59) Map3D_Frame = 0; 
	CP_UpdateMusic();
	if (joypad() & J_UP)A++;
	if (joypad() & J_DOWN)A--;
}
void main(){
	
	Map3D_Load();
	add_VBL(Map3D_update);

	while(1) {	//main loop
        //STAT_REG == ScanLine status 0, 1, 2 
		SWITCH_ROM_MBC1(3);
	    if (STAT_REG & 1) SCY_REG = A+ map3d_scanlines[LY_REG+Map3D_Frame] - LY_REG -1; 
		//wait_vbl_done();
	}	
}

/**/