/***********************
    CUTE DEMO
		BY MILLS
************************	

STORY
-----
Hi everyone. I was updating my shitty "second reality" port for DMG and CGB, but I just got bored of it, 
so I started this one. 

This demo contains some of the code I was doing for second reality, I just replaced the shapes, for example 
in the rotozoom scene.

My programming skills are not the best, and my math skills are way worst than the average human, (lowering 
my IQ score to 90 LOL). So many math related code is just the result of a LOT of boring hours trying to fit 
things, and solving incredibly stupid mistakes I make. 

Of course there will be bugs, due to some functions not working as my analog brain expects, resulting in small 
bugs barely noticeable on the real gameboy screen.


THE CODE
--------
Using ASM was incredibly difficult for me, so I used the horrible, buggy, slow GBDK. Well GBDK is good, most of 
the time it is working fine, but it has issues of course, that's why I had to implement custom ASM code and combine
it using "s" files (Thanks to the people in http://gbdev.gg8.se/forums/).

One of the biggest problems I found in GBDK, is the overwrite address bug, it shows if you don't 
use "const" arrays, or if you try to align arrays in s files.

Custom ASM functions are called from C, one of them is the DMA data transfer.
DMA transfer needs data to be aligned to 16 bit, but GBDK don't usually align data. So I had to 
tell the compiler to link the graphics data first, this way it always aligns the graphics, and then it stores 
the functions and everything else without disturbing the alignment :).

Custom ASM functions I used:
	-DMA transfer: animates bkg tiles (rotating sprockets, asteroids, 3d tower and fake parallax). 
	-Change palette every scan line: for the static backgrounds in zilog_inside scene and the 2d_sprocket scene.
	-Displaying High colour images: the cute tortoise.
	-Carillon music player: a binary block (no source available), called from whatever bank it is stored.
	
The rest of the code is just c, including some scan line effects (Fake perspective, 3d sprocket).


RESOURCES
---------
Many graphics were drawn by me and a friend, but This demo uses graphics taken from the internet, some Simpsons images 
(Homer and Lisa), and the music "Don't Stop" By 047.

CUTE DEMO was made just for learning purposes and FUN, so the whole demo can be licensed as CC and/or fair use.

At the end of CUTE DEMO you'll see a cute credits scene, that could be ripped from a hello kitty movie, containing all credits.


Hope you like it
	
*/