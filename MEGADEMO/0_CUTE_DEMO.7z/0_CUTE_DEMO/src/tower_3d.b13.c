#include <gb/gb.h>

extern const unsigned char Tower_Tiles[];
extern const unsigned char tower_anim_tiles[];
extern const unsigned char tower_anim_bkg[];

extern const unsigned char tower_sprite[];
extern const unsigned char tower_sprite_ghost[];
extern const unsigned char tower_spritePAL[];
extern const unsigned char Tower_MapPLN0[];
extern const unsigned char Tower_MapPLN1[];
extern UINT16 TIMER;

extern UINT8 Scene;
extern UINT8 v;
extern UINT8 SPR;
extern UINT8 SPRX;
extern UINT8 SPRY;
UINT16 TowerOffset;
UINT16 TowerOffset2;
UINT8 Tower_Align;
UINT16 BKGOffset;
UINT8 BKGSPEED;
UINT8 Fix[8] = {1,1,1,1,0,1,1,1};
//extern const UWORD Tower_SpritesPAL[];
extern const UWORD Tower_TilesPAL[];

void DMA_TRANSFER(UINT8 tiles, UINT16 *source,UINT16 *destination); 

const UINT8 sprite_tower_rot[96] =
{
	72,72,72,72,72,72,72,72,72,72,
	72,72,72,72,72,71,71,71,70,70,
	69,68,68,67,66,65,64,63,62,61,
	59,58,57,55,54,53,51,50,48,47,
	45,44,42,41,39,37,36,34,33,31,
	29,27,25,23,22,20,18,17,15,14,
	12,11, 9, 8, 7, 6, 5, 4, 3, 3,
	 2, 1, 1, 1, 0, 0, 0, 0, 0, 0, 
	 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
	 0, 0, 0, 0, 0, 0 
};

const UINT8 ghost_move[] =
{
	80, 84, 88, 92, 96,
100, 104, 108, 111, 115, 118, 121, 124, 127, 129,
131, 133, 135, 137, 138, 139, 139, 139, 139, 139,
139, 138, 137, 135, 133, 131, 129, 127, 124, 121,
118, 115, 111, 108, 104, 100, 96, 92, 88, 84,
79, 75, 71, 67, 63, 59, 55, 51, 48, 44,
41, 38, 35, 32, 30, 28, 26, 24, 22, 21,
20, 20, 20, 20, 20, 20, 21, 22, 24, 26,
28, 30, 32, 35, 38, 41, 44, 48, 51, 55,
59, 63, 67, 71, 75, 80
};

struct Rotating_Block{
	UINT8 sprite_number;
	UINT16 offset;
	UINT16 dat_offset;
	UINT8 rot_offset;
	UINT8 fix;
};

void Rot_Tower_Sprite(struct Rotating_Block* block, UINT8 posy){
  if(block->fix == 2){
	//VBK_REG = 0;
	set_sprite_data(block->sprite_number, 4, &tower_sprite+block->dat_offset);
	move_sprite(block->sprite_number/2,48+sprite_tower_rot[block->rot_offset],posy);
	move_sprite((block->sprite_number/2) + 1,56+sprite_tower_rot[block->rot_offset],posy);
	
	if (Tower_Align == 0){
		if (block->rot_offset < 95) block->rot_offset++;
		if (block->dat_offset < 95*32) block->dat_offset+=32;
	}
	if (Tower_Align == 1){
		if (block->rot_offset == 95) block->rot_offset = 0;
		if (block->dat_offset == 95*32) block->dat_offset = 0;
	}
	block->fix = 0;
  }
  block->fix++;
}

struct Rotating_Block block1;
struct Rotating_Block block2;
struct Rotating_Block block3;
struct Rotating_Block block4;


void Tower_Set(){
    TIMER = 0; 
	
	cpu_fast(); //CPU a 8 Mhz

	//DISPLAY_OFF;
	SPRITES_8x16;
	set_bkg_palette(0, 8, Tower_TilesPAL); //tile bank 1
	VBK_REG = 0;	  
		set_bkg_tiles( 0, 0, 20, 18, Tower_MapPLN0); //tiles
		//set_win_tiles(0, 0, 20, 18, Zilog_Win);
		set_bkg_data( 0, 34, Tower_Tiles); //tile bank 1
		set_sprite_palette( 0, 8, tower_spritePAL);
		set_sprite_data( 0, 16, tower_sprite_ghost);//in 8x8 mode!!!
		set_sprite_data( 16, 16, tower_sprite_ghost);
		set_sprite_data( 32, 16, tower_sprite_ghost);
		SPR = 0; 
		for (v = 0; v<40;v++){
			set_sprite_tile(v, SPR);
			SPR+=2;
		}
	VBK_REG = 1;	   
		set_bkg_tiles( 0, 0, 20, 18, Tower_MapPLN1); //tiles
		for (v = 0; v<8;v++) set_sprite_prop(v, 0x01);
		for (v = 8; v<24;v++) set_sprite_prop(v, 0x21);
		for (v = 24; v<40;v++) set_sprite_prop(v, 0x00);

	VBK_REG = 0;	  
	
	DISPLAY_ON;
	SHOW_BKG;
	SHOW_SPRITES;
	//SHOW_WIN;
	//WY_REG = 0;

	BKGOffset = 0;
	TowerOffset = 0;
	TowerOffset2 = 896;
	Tower_Align = 1;
	
	BKGSPEED = 0;

	block1.sprite_number = 48; block1.offset = 0x8300; block1.dat_offset = 0; block1.rot_offset = 0; block1.fix = 0;
	block2.sprite_number = 52; block2.offset = 0x8380; block2.dat_offset = 256; block2.rot_offset = 8; block2.fix = 0;
	block3.sprite_number = 56; block3.offset = 0x8400; block3.dat_offset = 1024; block3.rot_offset = 32; block3.fix = 0;
	block4.sprite_number = 60; block4.offset = 0x8480; block4.dat_offset = 1024+256; block4.rot_offset = 40; block4.fix = 0;
	
	Scene = 10;
	
}	


void Tower_Run(){
	//if (TIMER == 400) {Scene = 2;TIMER = 0;}
	if (Fix[BKGSPEED] == 1){
		VBK_REG = 0;
		DMA_TRANSFER(4,&tower_anim_bkg+BKGOffset,0x9000);//(change bkg tiles)
		DMA_TRANSFER(16,&tower_anim_tiles+TowerOffset,0x9000+4*16);//(change bkg tiles)
		DMA_TRANSFER(16,&tower_anim_tiles+TowerOffset2,0x9000+20*16);//(change bkg tiles)
	
		TowerOffset+=128;
		TowerOffset2+=128;
		BKGOffset+=32;
	}
	
	Rot_Tower_Sprite(&block1,32);
	Rot_Tower_Sprite(&block2,64);
	Rot_Tower_Sprite(&block3,96);	
	Rot_Tower_Sprite(&block4,128);	

	///END OF DMA TRANSFERS
	
	BKGSPEED++;
	if (BKGSPEED == 8) BKGSPEED = 0;
	
	if (TowerOffset == 1920) {TowerOffset = 0; Tower_Align = 1;}
	else Tower_Align = 0;
	
	if (TowerOffset2 == 1920) TowerOffset2 = 0;
	if (BKGOffset == 1024) BKGOffset = 0;
	
	if(SPRX == 90) SPRX = 0;
	
	SPR = 0;
	for (v = 0;v<4;v++){
		move_sprite(v,ghost_move[SPRX]+SPR,SPRY);
		move_sprite(v+4,ghost_move[SPRX]+SPR,SPRY+16);
		SPR+=8;
	}
	SPR = 0;
	for (v = 11;v>7;v--){
		move_sprite(v,ghost_move[SPRX]+SPR-50,-SPRY+32);
		move_sprite(v+4,ghost_move[SPRX]+SPR-50,-SPRY+48);
		SPR+=8;
	}	
	SPR = 0;
	for (v = 19;v>15;v--){
		move_sprite(v,(ghost_move[SPRX]/2)+SPR,SPRY-48);
		move_sprite(v+4,(ghost_move[SPRX]/2)+SPR,SPRY-32);
		SPR+=8;
	}	
	
	SPRX++;
	SPRY--;

	TIMER++;
}