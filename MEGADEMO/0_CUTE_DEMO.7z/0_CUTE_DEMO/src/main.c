/*
    CUTE DEMO
	
*/
#include <gb/gb.h>

UINT8 Scene;
UINT8 Part;
UINT16 TIMER;
UINT8 v;
UINT8 SPR;

const unsigned char NULLT[] = {0x00,0x00,0x00,0x00};
//Global functions
void Reset_LCD(){ //It works!!!
	UINT16 v;
	wait_vbl_done();
	for  (v = 0; v < 255; v++){remove_VBL(v); remove_LCD(v);}
	LCDC_REG =  0x07;
	mode (0xE2);
	SCX_REG = 0; SCY_REG = 0;
}

void Reset_Palettes(){
	UINT8 X = 0; UINT8 Y = 0;
	VBK_REG = 1;
	for  (Y = 0; Y < 32; Y++){
		for  (X = 0; X < 32; X++) set_bkg_tiles( X, Y, 1, 1, NULLT); //tiles
	}
}

//Carillon Player Functions
void CP_LoadMusic(UINT8 bank,int song);
void CP_UpdateMusic();
void CP_StopMusic();


//SCENE FUNCTIONS

//Intro
UINT8 Loading;
void Intro_Set();
void Intro_Run();

//Cute Demo HColor Logo
void LoadHiClr (UINT8 bank, UINT8 time);

//Zilog Inside
void Zilog_Set();
void Zilog_Run();
void Scroll_Control1() {
	SCX_REG++; SCY_REG++;
	CP_UpdateMusic();
}

//3D Tower
void Tower_Set();
void Tower_Run();


//MAIN

void main(void){
	cpu_fast();

	Scene = 10;
	Part = 0;
	TIMER = 0;
	
	while(1){

		while (Scene == 0) {SWITCH_ROM_MBC1(3);Intro_Set();}	
		while (Scene == 1) {SWITCH_ROM_MBC1(3);Intro_Run();}
		while (Scene == 2) {LoadHiClr(2,10);Scene = 3;Reset_Palettes();}
		while (Scene == 3) {Zilog_Set();CP_LoadMusic(4,0);add_VBL(Scroll_Control1);}
		while (Scene == 4) Zilog_Run();
	
		while (Scene == 10) {SWITCH_ROM_MBC1(5);Tower_Set();}
		while (Scene == 11) {SWITCH_ROM_MBC1(5);VBK_REG = 0;Tower_Run();}
	}
}
