/***********************
    CUTE DEMO
		BY MILLS
************************	
	
Using only ASM was incredibly difficult for me, so I used the horrible, buggy... GBDK, mixed with asm s files.

One of the biggest problems I found in GBDK, is the overwrite address bug, it shows if you don't 
use "const" arrays, or if you try to align arrays in s files (ASM).

Yes, I had to use some custom asm functions and call them from C, one of them is the DMA data transfer.
DMA transfer needs data to be aligned to 16 bit, but GBDK don't usually align data. So I had to 
tell the compiler to link the graphics data first, this way it allways aligns the graphics, and then it stores 
the functions and everything else without disturbing the alignment :).

Custom asm functions I used:
	-DMA transfer: animates bkg tiles (rotating sprockets, asteroids, 3d tower and fake parallax). 
	-Change palette every scan line: for the static bkg s in "zilog inside" scene and the "sprocket" scene.
	-Displaying High colour images: the cute tortoise.
	-Carillon music player: a binary block (no source available), called from whatever bank it is stored.
	
The rest of the code is just c, including the scan line effects to fake perspective, and the 3d rotating figure.

Some functions won't work as I espected, resulting in small bugs barely noticeable on the real gameboy screen.

Hope you like it
	
*/
#include <gb/gb.h>

UINT8 Scene;
UINT8 Part;
UINT16 TIMER;
UINT8 v;
UINT8 SPR;
UINT8 SPRX;
UINT8 SPRY;

UINT16 LCDC_STAT;

const unsigned char NULLT[] = {0x00,0x00,0x00,0x00};
//Global functions
void w_vbl(); //Fix 
void relcd();
//Carillon Player Functions
void CP_LoadMusic(UINT8 bank,int song);
void CP_UpdateMusic();
void CP_StopMusic();


void Reset_LCD(){ //It works!!!
	UINT8 i;
	disable_interrupts();
	//CP_StopMusic();
	for (i=0;i!=32;++i) {
		remove_VBL(i); 
		remove_LCD(i); 
	}
	for (i=36;i!=255;++i) {
		remove_VBL(i); 
		remove_LCD(i); 
	}
	//LCDC_REG = LCDC_STAT;
	LCDC_REG = 0x18C0; 
	mode(0xE00); 
	SCX_REG = 0; SCY_REG = 0;
	enable_interrupts();
}

void Reset_Palettes(){
	UINT8 X = 0; UINT8 Y = 0;
	VBK_REG = 1;
	for  (Y = 0; Y < 32; Y++){
		for  (X = 0; X < 32; X++) set_bkg_tiles( X, Y, 1, 1, NULLT); //tiles
	}
}


//SCENE FUNCTIONS

//Intro
void Intro_Set();
void Intro_Run();

//Cute Demo HColor Logo
void LoadHiClr (UINT8 bank, UINT8 time);

//Zilog Inside
void Zilog_Set();
void Zilog_Run();

//3D Tower
void Tower_Set();
void Tower_Run();


void Scroll_Control1() {
	if (TIMER == 200) Scene = 10;
	SCX_REG++; SCY_REG++;
	CP_UpdateMusic();
	TIMER++;
}

void Scroll_Control2() {CP_UpdateMusic();}

//MAIN

void main(void){
	
	LCDC_STAT = LCDC_REG;
	
	cpu_fast();

	Scene = 0;
	Part = 0;
	TIMER = 0;
	
	while(1){

		while (Scene == 0) {SWITCH_ROM_MBC1(3);Intro_Set();}	
		while (Scene == 1) {SWITCH_ROM_MBC1(3);Intro_Run();}
		while (Scene == 2) {Reset_LCD();LoadHiClr(2,10);Scene = 3;Reset_Palettes();CP_LoadMusic(4,0);}
		while (Scene == 3) {Zilog_Set();add_VBL(Scroll_Control1);}
		while (Scene == 4) Zilog_Run();
		
		while (Scene == 10) {Reset_LCD();TIMER = 0; SWITCH_ROM_MBC1(5);Tower_Set(); add_VBL(Scroll_Control2);}
		while (Scene == 11) {wait_vbl_done();SWITCH_ROM_MBC1(5);Tower_Run();}
		
	}
}
