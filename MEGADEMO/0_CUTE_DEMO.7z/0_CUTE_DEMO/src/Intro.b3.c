
#include <gb/gb.h>
#include <gb/drawing.h>

extern UINT8 Part;
extern UINT8 Scene;
extern const UWORD Intro_MapPAL[]; //BLACK, RED, GREEN, WHITE
extern const unsigned char Intro_Map[];

UINT8 Loading;

void Reset_LCD();

void Intro_Set(){
	set_bkg_tiles( 0, 0, 20, 18, 0x0000); //tiles
	//mode(get_mode() | M_NO_INTERP | M_NO_SCROLL);
	if(_cpu == 0x01) {
		line(2,2,5,5);
		gotogxy(6,3);
		gprint("WARNING!!     ");
		gotogxy(4,5);
		gprint("Only for CGB");
		gotogxy(0,9);
		gprint("Do not get angry DMG");
		gotogxy(2,12);
		gprint("still love you :)");
		Part = 20;
	}
	if(_cpu == 0x11) {// if CGB
		cpu_fast();
		set_bkg_palette(0, 1, Intro_MapPAL); 	
	
		gprint(" ");
		color(2, 0, M_FILL);
		gotogxy(6,1);
		gprint("WARNING!!");
		color(3, 0, M_FILL);
		gotogxy(1,3);
		gprint("Program techniques  used here are well  known, so the goal  is not to show any  original code.");
		gotogxy(1,9);
		gprint("This demo was just  made to be:        ");
		gotogxy(2,12);
		color(1, 0, M_FILL);
		gprint("- cute              - colourfull      ");
		color(2, 0, M_FILL);
		gotogxy(4,16);
		gprint("(A) to continue ");	
	
		waitpad(J_A);
		Reset_LCD();
		gprint(" ");
		color(2, 0, M_FILL);
		gotogxy(6,1);
		gprint("THANKS!!");
		color(3, 0, M_FILL);
		gotogxy(1,4);
		gprint("Thanks to creators  of the resources &  program techniques  I used for this.    ");
		gprint("And thanks to the   Game Boy for being  so");
		color(1, 0, M_FILL);
		gprint(" cute");
		gotogxy(7,13);
		color(3, 0, M_FILL);	
		gprint("MILLS  2018");
		gotogxy(2,16);
		color(2, 0, M_FILL);
		gprint("PRESS A TO START");
	
		waitpad(J_A);
		gotogxy(0,0);
		Reset_LCD();
		set_bkg_palette(0, 1, &Intro_MapPAL + 4); 
	}
	
	Loading = 0;
	Part = 0;
	Scene = 1;
}

void Intro_Run(){
	

	if (Part == 0){
		draw_image(Intro_Map);
		gotogxy(1,6);
		color(3, 2, M_FILL);
		gprint("LOADING...");
		cpu_slow();
		Part = 1;
	}
	
	if (Part == 1){

		color(1, 0, M_NOFILL);
		line(34+Loading,74,34+Loading,85);
		
		/////
		if (Loading == 0){
			color(3, 2, M_NOFILL);
			gotogxy(4,12);
			gprint("Meta code   ");
		}
		if (Loading == 30){	
			color(3, 2, M_NOFILL);
			gotogxy(4,12);
			gprint("voxels   ");
		}
		if (Loading == 40){	
			color(3, 2, M_NOFILL);
			gotogxy(4,12);
			gprint("Worm Holes");
		}
		if (Loading == 70){
			color(3, 2, M_FILL);
			gotogxy(4,12);
			gprint("ERROR:");
			color(3, 2, M_FILL);
			gprint("      ");
			color(3, 2, M_FILL);
			gotogxy(4,13);
			gprint("DIVIDED BY 0");
			delay(2000);
		}
		if (Loading == 90){
			Reset_LCD();
			set_bkg_data(0, 300, Intro_MapPAL); 
			color(3, 2, M_NOFILL);
			gotogxy(2,7);
			gprint("CRITICAL EVENT!!");
			color(1, 0, M_NOFILL);
			gotogxy(1,12);
			gprint("GENERATE UNIVERSE?");
			color(3, 2, M_NOFILL);
			gotogxy(1,13);
			gprint("    YES  -  NO    ");
			delay(1000);
		}	
		
		if (Loading == 128-32){Loading = 0; Part = 2;}
		delay(60);
		Loading++;
		wait_vbl_done();
		
	}	
	
	if (Part == 2){
		color(0, 0, M_FILL);
		SCX_REG++;
		if (Loading == 128) {DISPLAY_OFF; Scene = 2; Part = 0; Reset_LCD(); cpu_fast();} //Go to next program
		if (LY_REG == 0)Loading++;
	}
	
	//if (Part = 20) wait_vbl_done();
}
