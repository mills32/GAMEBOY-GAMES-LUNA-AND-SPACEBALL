#include <gb/gb.h>

extern const unsigned char Tower_Tiles[];
extern const unsigned char tower_anim_tiles[];
extern const unsigned char tower_anim_bkg[];

//extern const unsigned char Tower_Sprites[];
extern const unsigned char Tower_MapPLN0[];
extern const unsigned char Tower_MapPLN1[];
extern UINT16 TIMER;

extern UINT8 Scene;
extern UINT8 v;
extern UINT8 SPR;
UINT16 TowerOffset;
UINT16 TowerOffset2;
UINT16 BKGOffset;
UINT8 WSPEED;
//extern const UWORD Tower_SpritesPAL[];
extern const UWORD Tower_TilesPAL[];

void ROTATE_TOWER(UINT16 *data); //in asm 
void ROTATE_TOWER2(UINT16 *data); //in asm 
void SCROLL_TOWER_BKG(UINT16 *data); //in asm 


void Tower_Set(){
    TIMER = 0; 
 
	cpu_fast(); //CPU a 8 Mhz
	wait_vbl_done();
	
	DISPLAY_OFF;

	//SPRITES_8x16;
	set_bkg_palette(0, 8, Tower_TilesPAL); //tile bank 1
	VBK_REG = 0;	   
		set_bkg_tiles( 0, 0, 20, 18, Tower_MapPLN0); //tiles
		//set_win_tiles(0, 0, 20, 18, Zilog_Win);
		set_bkg_data( 0, 34, Tower_Tiles); //tile bank 1
		//set_sprite_palette( 0, 1, Tower_SpritesPAL);
		//set_sprite_data(0, 39, Tower_Sprites);
	VBK_REG = 1;	   
		set_bkg_tiles( 0, 0, 20, 18, Tower_MapPLN1); //tiles	
		/*SPR = 0;
		for (v = 0; v<14;v++){
			set_sprite_tile(v, SPR);
			SPR += 2;
		}
		
		SPR = 0;
		*/
	VBK_REG = 0;	   
	
    DISPLAY_ON;
	SHOW_BKG;
	
	//SHOW_WIN;
	
	//WY_REG = 0;
	/*
	SHOW_SPRITES;
	for (v = 0; v<10;v++) move_sprite(v,(v+3)*8,16);
	for (v = 10; v<13;v++) move_sprite(v,((v+3)*8)-40,36);
	*/
	Scene = 11;
	BKGOffset = 0;
	TowerOffset = 0;
	TowerOffset2 = 896;
	WSPEED = 0;
}	

void Tower_Run(){
	
	if (TowerOffset == 1920) TowerOffset = 0;
	if (TowerOffset2 == 1920) TowerOffset2 = 0;
	
	wait_vbl_done();
	
	ROTATE_TOWER(&tower_anim_tiles+TowerOffset);//(change bkg tiles)
	ROTATE_TOWER2(&tower_anim_tiles+TowerOffset2);//(change bkg tiles)
	TowerOffset+=128;
	TowerOffset2+=128;
	
	if (WSPEED == 2){
		if (BKGOffset == 256) BKGOffset = 0;
		SCROLL_TOWER_BKG(&tower_anim_bkg+BKGOffset);//(change bkg tiles)
		BKGOffset+=16;
		WSPEED = 0;
	}
	
	WSPEED++;
}