#include <gb/gb.h>


extern const unsigned char RoadBKGMap3DPLN0[];
extern const unsigned char RoadBKGMap3DPLN1[];
extern const unsigned char RoadFMap3DPLN0[];
extern const unsigned char RoadFMap3DPLN1[];
extern const unsigned char Road3DTiles[];
extern const unsigned char Road3DAnim[];
extern const unsigned char Road3Dsprites[];
extern const unsigned char Road3DspritesPAL[];
const unsigned char Road3DspritesCGB[] =
{
  0x00,0x03,0x03,0x00,0x02,0x02,0x02,0x02,
  0x01,0x02,0x02,0x01,0x02,0x02,0x02,0x01,
  0x02,0x02,0x02,0x01,0x01,0x02,0x01,0x01
};
extern const UWORD Road3DTilesPAL[];
extern const unsigned char map3d_scanlines[]; 

const unsigned char VanMovement[] = {0,0,1,1,1,2,2,2,1,1,1,0};

UINT16 Map3D_Frame; 

extern UINT8 Scene;
extern UINT8 v;
extern UINT8 SSPEED;
extern UINT8 SSPEED1;
extern UINT8 SPR;
extern UINT8 SPRY;
extern UINT16 TIMER;

void Road3D_Set(){

	VBK_REG = 0;
	   set_bkg_data(0, 80, Road3DTiles);
	   set_bkg_tiles( 0, 0, 32, 12, RoadBKGMap3DPLN0);
	   set_win_tiles( 0, 0, 20, 6, RoadFMap3DPLN0);
	   set_sprite_data( 0, 46, Road3Dsprites);//in 8x8 mode!!!
	   SPR = 0; 
	   for (v = 0; v<23;v++){set_sprite_tile(v, SPR);SPR+=2;}
	VBK_REG = 1;	   
	   set_bkg_tiles( 0, 0, 32, 12, RoadBKGMap3DPLN1); 
	   set_win_tiles( 0, 0, 20, 6, RoadFMap3DPLN1);
	   
	   for (v = 0; v<28;v++) set_sprite_prop(v, Road3DspritesCGB[v]);
	VBK_REG = 0;
	
	set_bkg_palette(0, 8, Road3DTilesPAL);
	set_sprite_palette( 0, 8, Road3DspritesPAL);
	
	SHOW_BKG;
	WY_REG = 12*8;
	SHOW_WIN;
	SHOW_SPRITES;
	
	SSPEED = 0;
	SSPEED1 = 0;
	SPRY = 0;
	
	Map3D_Frame = 0;
	TIMER = 0;
	
	Scene++;
}	


void Road3D_Run(){
	
	if(TIMER == 800) {
		TIMER = 0; Scene++; 
		HIDE_WIN;
		for (v = 0;v=!40;v++)move_sprite(v,180,180);
	}
	if(SSPEED == 5){SSPEED = 0;SCX_REG++;}
	SSPEED++;
	
	if(SSPEED1 == 2){SSPEED1 = 0;Map3D_Frame+=30*16;}
	SSPEED1++;
	
	if (Map3D_Frame == 30*16*15) Map3D_Frame = 0; 
	
	//VAN
	SPR = 0;
	for (v = 0;v<4;v++){
		move_sprite(v,56+SPR,112+VanMovement[SPRY]);
		move_sprite(v+4,56+SPR,128+VanMovement[SPRY]);
		move_sprite(v+8,56+SPR,140);
		SPR+=8;
	}
	
	if(SPRY == 11) SPRY = 0;
	SPRY++;
	
	TIMER++;
	
}

/**/