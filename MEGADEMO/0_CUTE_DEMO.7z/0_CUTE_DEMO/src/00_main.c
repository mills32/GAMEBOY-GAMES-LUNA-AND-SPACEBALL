/***********************
    CUTE DEMO
		BY MILLS
************************	
	
Using only ASM was incredibly difficult for me, so I used the horrible, buggy... GBDK, mixed with asm s files.

One of the biggest problems I found in GBDK, is the overwrite address bug, it shows if you don't 
use "const" arrays, or if you try to align arrays in s files (ASM).

Yes, I had to use some custom asm functions and call them from C, one of them is the DMA data transfer.
DMA transfer needs data to be aligned to 16 bit, but GBDK don't usually align data. So I had to 
tell the compiler to link the graphics data first, this way it allways aligns the graphics, and then it stores 
the functions and everything else without disturbing the alignment :).

Custom asm functions I used:
	-DMA transfer: animates bkg tiles (rotating sprockets, asteroids, 3d tower and fake parallax). 
	-Change palette every scan line: for the static bkg s in "zilog inside" scene and the "sprocket" scene.
	-Displaying High colour images: the cute tortoise.
	-Carillon music player: a binary block (no source available), called from whatever bank it is stored.
	
The rest of the code is just c, including the scan line effects to fake perspective, and the 3d rotating figure.

Some functions won't work as I espected, resulting in small bugs barely noticeable on the real gameboy screen.

Hope you like it
	
*/
#include <gb/gb.h>

UINT8 Scene;
UINT8 Part;
UINT16 TIMER;
UINT8 v;
UINT8 SPR;
UINT8 SPRX;
UINT8 SPRY;
UINT8 SSPEED;
UINT8 SSPEED1;
UINT8 FontN;

const unsigned char NULLT[] = {0x00,0x00,0x00,0x00};
const unsigned char Black_PAL[] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
//Global functions
void w_vbl(); //Fix 
void relcd();
//Carillon Player Functions
void CP_LoadMusic(UINT8 bank,int song);
void CP_UpdateMusic();
void CP_StopMusic();


//Font sprite table
/*	Number		Sprite
	0-9		= 	0-9
	10		=	A
	11		=	B
	.
	20		=	K
	.
	35		=	Z
	36		=	!
	37		=	'
	38		=	?
	39		=	.
	
	power / by = 28 sprites
	
	lisa / needs = 36 sprites 
	dental / care = 36 sprites
	
	spin / me = 24
	like a = 20
	game / boy = 28
	
	
*/

void Reset_LCD(){ //It works!!!
	UINT8 i;
	wait_vbl_done();
	disable_interrupts();
	for (i=36;i!=48;++i) {
		remove_VBL(i); 
		//remove_LCD(i); 
	}
	SCX_REG = 0; SCY_REG = 0;
	enable_interrupts();
}

void Reset_Palettes(){
	UINT8 X = 0; UINT8 Y = 0;
	VBK_REG = 1;
	for  (Y = 0; Y < 32; Y++){
		for  (X = 0; X < 32; X++) set_bkg_tiles( X, Y, 1, 1, NULLT); //tiles
	}
}

void Transition(){
	HIDE_SPRITES;
	set_bkg_palette(0, 8, Black_PAL);
	SHOW_WIN;
	WY_REG = 0;
}

//SCENE FUNCTIONS

//Intro
void Intro_Set();
void Intro_Run();

//Cute Demo HColor Logo
void LoadHiClr (UINT8 bank, UINT8 time);

//Zilog Inside
void Zilog_Set();
void Zilog_Run();

//Perspective 3D
void Persp3D_Load();
void Persp3D_update();
void Perspective3D_Scanlines();
void Scroll_Control2() {
	SWITCH_ROM_MBC1(0);
	CP_UpdateMusic();
	SWITCH_ROM_MBC1(5);
	Persp3D_update();
}

//3D Road
void Road3D_Set();
void Road3D_Run();
void Road3D_DMA();

//Driving Homer
void Homer_Set();
void Homer_Run();


//3D Tower
void Tower_Set();
void Tower_Run();


//MAIN

void main(void){

	cpu_fast();

	Scene = 0;
	Part = 0;
	TIMER = 0;
	
	SPRITES_8x16;
	
	while(1){
		
		while (Scene == 0) {Intro_Set();}	
		while (Scene == 1) {Intro_Run();}

		while (Scene == 2) {LoadHiClr(2,10);Scene = 3;}

		while (Scene == 3) {CP_LoadMusic(4,0);Reset_Palettes();Transition();Zilog_Set();}
		while (Scene == 4) Zilog_Run();
		
		while (Scene == 5) {Reset_LCD();Transition();SWITCH_ROM_MBC1(5);Persp3D_Load();add_VBL(Scroll_Control2);}
		while (Scene == 6) {SWITCH_ROM_MBC1(5);Perspective3D_Scanlines();}
		
		while (Scene == 7) {Reset_LCD();Transition();TIMER = 0; SWITCH_ROM_MBC1(3);Road3D_Set();add_VBL(CP_UpdateMusic);}
		while (Scene == 8) {wait_vbl_done();SWITCH_ROM_MBC1(6);Road3D_DMA();SWITCH_ROM_MBC1(3);Road3D_Run();}
		
		while (Scene == 9) {Reset_LCD();Transition();SWITCH_ROM_MBC1(3);Homer_Set();add_VBL(CP_UpdateMusic);}
		while (Scene == 10) {wait_vbl_done();SWITCH_ROM_MBC1(3);Homer_Run();}
		
		while (Scene == 11) {Reset_LCD();Transition();SWITCH_ROM_MBC1(13);Tower_Set();add_VBL(CP_UpdateMusic);}
		while (Scene == 12) {wait_vbl_done();SWITCH_ROM_MBC1(13);Tower_Run();}
		
		while (Scene == 15) {wait_vbl_done();SWITCH_ROM_MBC1(13);Tower_Run();}
		while (Scene == 15) {wait_vbl_done();SWITCH_ROM_MBC1(13);Tower_Run();}
		while (Scene == 15) {wait_vbl_done();SWITCH_ROM_MBC1(13);Tower_Run();}
		while (Scene == 15) {wait_vbl_done();SWITCH_ROM_MBC1(13);Tower_Run();}
		while (Scene == 15) {wait_vbl_done();SWITCH_ROM_MBC1(13);Tower_Run();}
		while (Scene == 15) {wait_vbl_done();SWITCH_ROM_MBC1(13);Tower_Run();}
		while (Scene == 15) {wait_vbl_done();SWITCH_ROM_MBC1(13);Tower_Run();}
		while (Scene == 15) {wait_vbl_done();SWITCH_ROM_MBC1(13);Tower_Run();}
		while (Scene == 15) {wait_vbl_done();SWITCH_ROM_MBC1(13);Tower_Run();}
		while (Scene == 15) {wait_vbl_done();SWITCH_ROM_MBC1(13);Tower_Run();}
		while (Scene == 15) {wait_vbl_done();SWITCH_ROM_MBC1(13);Tower_Run();}
		while (Scene == 15) {wait_vbl_done();SWITCH_ROM_MBC1(13);Tower_Run();}
		while (Scene == 15) {wait_vbl_done();SWITCH_ROM_MBC1(13);Tower_Run();}
		while (Scene == 15) {wait_vbl_done();SWITCH_ROM_MBC1(13);Tower_Run();}
		while (Scene == 15) {wait_vbl_done();SWITCH_ROM_MBC1(13);Tower_Run();}
		while (Scene == 15) {wait_vbl_done();SWITCH_ROM_MBC1(13);Tower_Run();}
		while (Scene == 15) {wait_vbl_done();SWITCH_ROM_MBC1(13);Tower_Run();}
		while (Scene == 15) {wait_vbl_done();SWITCH_ROM_MBC1(13);Tower_Run();}
		
	}
}
