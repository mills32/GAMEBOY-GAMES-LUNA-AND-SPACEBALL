#include <gb/gb.h>
#include "fade.h"

UWORD FadePalette[32] = {
    RGB(30,0,0), RGB(0,30,0), RGB(0,0,30), RGB(0,0,0)
};

void Fade(UWORD *org_p, FadeDirection direction, FadeColor color, UWORD speed)
{
    UBYTE i,x;
    UWORD bit_mask;

    bit_mask = (direction == FadeDirectionFrom)
        ? 0x0421    // 0000010000100001 
        : 0x4210;   // 0100001000010000 

    for (i = 0; i < 5; i++) { /* 5 bits per color */
        for (x = 0; x < 32; x++) {
            if (direction == FadeDirectionFrom && color == FadeColorBlack) {
                // fade from black 
                FadePalette[x] = org_p[x] & bit_mask;
            } else if (direction == FadeDirectionFrom && color == FadeColorWhite) {
                // fade from white 
                FadePalette[x] = org_p[x] | (0x7FFF & ~bit_mask);
            } else if (direction == FadeDirectionTo && color == FadeColorBlack) {
                // fade to black 
                FadePalette[x] = org_p[x] & ~bit_mask;
            } else if (direction == FadeDirectionTo && color == FadeColorWhite) {
                // fade to white 
                FadePalette[x] = org_p[x] | bit_mask;
            }
        }

        bit_mask |= (direction == FadeDirectionFrom)
            ? (bit_mask << 1)
            : (bit_mask >> 1);
			
		delay(speed);
		wait_vbl_done();
        set_bkg_palette(0,8, &FadePalette[0]);
		
    }
}
