#ifndef _GBX_FADE_H
#define _GBX_FADE_H

typedef enum {
    FadeDirectionFrom,
    FadeDirectionTo
} FadeDirection;

typedef enum {
    FadeColorBlack,
    FadeColorWhite
} FadeColor;

void Fade(UWORD *org_p, FadeDirection direction, FadeColor color, UWORD speed);


#endif
