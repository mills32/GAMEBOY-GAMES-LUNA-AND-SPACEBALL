#include <gb/gb.h>
#include "fade.h"

	extern const UWORD PalmTilesPAL[];
	extern const unsigned char PalmTiles[];
	extern const unsigned char PalmMapPLN0[];
	extern const unsigned char PalmMapPLN1[];


void CP_LoadMusic(UINT8 bank,UINT8 sbank,int song);
void CP_UpdateMusic();
void CP_SelectSong(UINT8 song); 
void CP_StopMusic();


void Scene1() {
	

	cpu_fast();
	wait_vbl_done();
	DISPLAY_OFF;
	HIDE_BKG;
	SWITCH_ROM_MBC1(1);
	//set_bkg_palette(0, 8, PalmTilesPAL);
	//set_sprite_palette(0, 8, spritecolours);
	VBK_REG = 0;	   
	   set_bkg_tiles( 0, 0, 20, 18, PalmMapPLN0); 
	VBK_REG = 1;	   
	   set_bkg_tiles( 0, 0, 20, 18, PalmMapPLN1); 	
	VBK_REG = 0;
	   set_bkg_data(0, 256, PalmTiles); 
	   
	SHOW_SPRITES;
	SHOW_BKG;
	
	DISPLAY_ON;	
	Fade(PalmTilesPAL,FadeDirectionFrom, FadeColorWhite,50);
	CP_LoadMusic(2,0,0);
	
}

void main(){
    Scene1();
	
	disable_interrupts();
	enable_interrupts();
	
	//TMA_REG = 120;
	//TAC_REG = 0x04U;
	
	//set_interrupts(TIM_IFLAG);
	
	while(1) {	//main loop	
		CP_UpdateMusic();

		wait_vbl_done();
	}	
}
